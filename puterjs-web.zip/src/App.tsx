import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu, Plus, Mic, Square, Paperclip, Image as ImageIcon, FileText,
  Settings2, FolderOpen, ChevronDown, FlaskConical, X, Check,
  Download, Trash2, Sparkles, Zap, Brain, Globe, ArrowUp, CircleAlert,
} from "lucide-react";
import { MODEL_CATALOG, getModel, checkParams, contentToString, estimateTokens, loadPuter } from "./lib/puter";
import { store, uid, timeAgo, sessionTokens, PROMPT_STARTERS, type ChatSession, type ChatMessage, type Attachment, type WorkspaceFile, type AppSettings, type ToolCallRecord, fileToDataUrl } from "./lib/store";
import { LeftSidebar, SettingsDrawer, WorkspaceDrawer } from "./components/Sidebars";
import { ImageLab, VideoLab, VoiceLab } from "./components/StudioViews";
import { Md, Thinking, ToolTray, TypingDots, AttachmentThumbs, ErrorCard, MsgActions } from "./components/ChatView";
import { Chip, IconBtn, Meter, ModalShell } from "./components/ui";
import { cn } from "./utils/cn";

type View = "chat" | "image" | "video" | "audio";

// ─── local tool definitions ───
const LOCAL_TOOLS = [
  { type: "function", function: { name: "calculator", description: "Evaluate a math expression. Use for arithmetic, percentages, unit math.", parameters: { type: "object", properties: { expression: { type: "string", description: "e.g. (240*0.15)+12, sqrt(144), 2^10" } }, required: ["expression"] } } },
  { type: "function", function: { name: "get_datetime", description: "Get current date/time, timezone and ISO string.", parameters: { type: "object", properties: {} } } },
  { type: "function", function: { name: "workspace_lookup", description: "Search attached workspace files for a query and return matching snippets.", parameters: { type: "object", properties: { query: { type: "string" } }, required: ["query"] } } },
  { type: "function", function: { name: "fetch_url_text", description: "Fetch a public URL and return its text (fallback web search for non-OpenAI models).", parameters: { type: "object", properties: { url: { type: "string" }, max_chars: { type: "number" } }, required: ["url"] } } },
];

function safeCalc(expr: string): string {
  try {
    let e = expr.trim().replace(/\^/g, "**").replace(/sqrt\(/gi, "Math.sqrt(").replace(/pow\(/gi, "Math.pow(");
    if (!/^[0-9+\-*/().\s%Math,sqrta-z*,]+$/i.test(e)) throw new Error("invalid chars");
    if (e.length > 200) throw new Error("too long");
    const v = Function(`"use strict"; const {PI,E,sqrt,pow,sin,cos,tan,log,abs,floor,ceil,round,min,max} = Math; return (${e});`)();
    if (typeof v !== "number" || !isFinite(v)) throw new Error("no numeric result");
    return `${expr} = ${v}`;
  } catch (err: any) { return `calc error: ${err?.message || err}`; }
}

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => store.settings);
  const [sessions, setSessions] = useState<ChatSession[]>(() => store.sessions);
  const [activeId, setActiveId] = useState<string | null>(() => store.sessions[0]?.id ?? null);
  const [workspace, setWorkspace] = useState<WorkspaceFile[]>(() => store.workspace);
  const [usage, setUsage] = useState(() => store.usage);
  const [view, setView] = useState<View>("chat");
  const [sideOpen, setSideOpen] = useState(false);
  const [setOpen, setSetOpen] = useState(false);
  const [wsOpen, setWsOpen] = useState(false);
  const [modelOpen, setModelOpen] = useState(false);
  const [modelQ, setModelQ] = useState("");
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [streaming, setStreaming] = useState(false);
  const [streamText, setStreamText] = useState("");
  const [streamReason, setStreamReason] = useState("");
  const [streamTools, setStreamTools] = useState<ToolCallRecord[]>([]);
  const [puterOk, setPuterOk] = useState<boolean | null>(null);
  const [authed, setAuthed] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [liveModels, setLiveModels] = useState<any[]>([]);
  const [toasts, setToasts] = useState<{ id: string; msg: string }[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [listening, setListening] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [attachMenu, setAttachMenu] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef(false);
  const imgIn = useRef<HTMLInputElement>(null);
  const fileIn = useRef<HTMLInputElement>(null);
  const audIn = useRef<HTMLInputElement>(null);
  const recogRef = useRef<any>(null);

  const toast = useCallback((msg: string) => {
    const id = uid();
    setToasts((t) => [...t, { id, msg }].slice(-3));
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  // theme
  useEffect(() => {
    document.documentElement.classList.toggle("dark", settings.theme === "dark");
    document.documentElement.classList.toggle("light", settings.theme === "light");
    document.body.style.background = settings.theme === "dark" ? "#09090b" : "#fafafa";
    document.body.style.color = settings.theme === "dark" ? "#fafafa" : "#0a0a0b";
  }, [settings.theme]);

  // persist
  useEffect(() => { store.settings = settings; }, [settings]);
  useEffect(() => { store.sessions = sessions; }, [sessions]);
  useEffect(() => { store.workspace = workspace; }, [workspace]);
  useEffect(() => { store.usage = usage; }, [usage]);

  // puter boot
  useEffect(() => {
    loadPuter().then(async (p) => {
      setPuterOk(true);
      try {
        const signed = await p.auth.isSignedIn();
        setAuthed(!!signed);
        if (signed) { try { setUser(await p.auth.getUser()); } catch { /* noop */ } }
      } catch { /* noop */ }
      try {
        const list = await p.ai.listModels();
        if (Array.isArray(list)) setLiveModels(list);
      } catch { /* noop */ }
    }).catch(() => setPuterOk(false));
  }, []);

  const sessionsRef = useRef(sessions);
  sessionsRef.current = sessions;
  const active = useMemo(() => sessions.find((s) => s.id === activeId) ?? null, [sessions, activeId]);
  const model = useMemo(() => getModel(settings.model), [settings.model]);
  const checks = useMemo(() => checkParams(settings.model, { reasoning_effort: settings.reasoning_effort, temperature: settings.temperature }), [settings.model, settings.reasoning_effort, settings.temperature]);
  const effectiveStream = settings.stream && !model.caps.imageGen;

  // autoscroll
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [active?.messages.length, streamText, streamReason, view]);

  const updateSession = useCallback((id: string, fn: (s: ChatSession) => ChatSession) => {
    setSessions((prev) => prev.map((s) => (s.id === id ? fn(s) : s)));
  }, []);

  const newChat = useCallback(() => {
    const s: ChatSession = { id: uid(), title: "New conversation", model: settings.model, createdAt: Date.now(), updatedAt: Date.now(), messages: [], totalIn: 0, totalOut: 0 };
    setSessions((p) => [s, ...p]);
    setActiveId(s.id); setView("chat"); setInput(""); setAttachments([]);
    setTimeout(() => taRef.current?.focus(), 50);
  }, [settings.model]);

  useEffect(() => {
    if (sessions.length === 0) {
      const s: ChatSession = { id: uid(), title: "New conversation", model: settings.model, createdAt: Date.now(), updatedAt: Date.now(), messages: [], totalIn: 0, totalOut: 0 };
      setSessions([s]); setActiveId(s.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const doAuth = useCallback(async () => {
    try {
      const p = await loadPuter();
      if (authed) { await p.auth.signOut(); setAuthed(false); setUser(null); toast("Signed out of Puter"); }
      else { await p.auth.signIn(); const u = await p.auth.getUser().catch(() => null); setUser(u); setAuthed(true); toast(u?.username ? `Signed in as ${u.username}` : "Puter connected"); }
    } catch (e: any) { toast("Auth: " + (e?.message || e)); }
  }, [authed, toast]);

  // ─── tools execution ───
  const runLocalTool = useCallback(async (name: string, args: any): Promise<string> => {
    const t0 = performance.now();
    void t0;
    if (name === "calculator") return safeCalc(String(args?.expression ?? ""));
    if (name === "get_datetime") { const d = new Date(); return `${d.toString()}\nISO: ${d.toISOString()}\nTZ offset: ${-d.getTimezoneOffset() / 60}h`; }
    if (name === "workspace_lookup") {
      const q = String(args?.query ?? "").toLowerCase();
      const hits: string[] = [];
      workspace.filter((f) => f.attach).forEach((f) => {
        if (f.kind === "image") return;
        const idx = f.content.toLowerCase().indexOf(q);
        if (q && idx >= 0) hits.push(`### ${f.name}\n…${f.content.slice(Math.max(0, idx - 200), idx + 600)}…`);
        else if (!q) hits.push(`### ${f.name}\n${f.content.slice(0, 600)}`);
      });
      return hits.length ? hits.join("\n\n").slice(0, 6000) : "No matches in attached workspace files.";
    }
    if (name === "fetch_url_text") {
      try {
        const r = await fetch(String(args.url), { signal: AbortSignal.timeout(12000) });
        const t = await r.text();
        return t.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(0, Number(args?.max_chars) || 6000);
      } catch (e: any) { return "fetch failed: " + (e?.message || e); }
    }
    return `unknown tool: ${name}`;
  }, [workspace]);

  const buildTools = useCallback(() => {
    const tools: any[] = [];
    if (settings.enableWebSearch && model.caps.webSearch) tools.push({ type: "web_search" });
    if (settings.enableFunctions) {
      const fns = [...LOCAL_TOOLS];
      if (settings.enableWebSearch && !model.caps.webSearch) { /* fetch_url_text already included as fallback */ }
      else if (!settings.enableWebSearch) { const i = fns.findIndex((t: any) => t.function.name === "fetch_url_text"); if (i >= 0) fns.splice(i, 1); }
      tools.push(...fns);
    }
    return tools;
  }, [settings.enableWebSearch, settings.enableFunctions, model.caps.webSearch]);

  const buildMessages = useCallback((sess: ChatSession, userText: string, atts: Attachment[]) => {
    const attached = settings.enableWorkspace ? workspace.filter((f) => f.attach && f.kind !== "image") : [];
    const wsImages = settings.enableWorkspace ? workspace.filter((f) => f.attach && f.kind === "image").slice(0, 3) : [];
    let sys = settings.systemPrompt;
    if (attached.length) {
      const ctx = attached.map((f) => `### ${f.name}\n${f.content.slice(0, 8000)}`).join("\n\n").slice(0, 16000);
      sys += `\n\n[WORKSPACE CONTEXT — attached local files]\n${ctx}`;
    }
    const sysMsg: any = { role: "system", content: sys };
    if (settings.enableCache && (model.vendor === "anthropic" || settings.model.toLowerCase().includes("claude"))) sysMsg.cache_control = { type: "ephemeral" };

    const hist: any[] = sess.messages.filter((m) => m.role !== "system" && !m.error).slice(-24).map((m) => {
      if (m.role === "assistant" && m.toolCalls?.length) {
        return { role: "assistant", content: m.text || "", tool_calls: m.toolCalls.map((t) => ({ id: t.id, type: "function", function: { name: t.name, arguments: JSON.stringify(t.args) } })) };
      }
      if ((m as any).isToolResult) return m;
      return { role: m.role, content: m.text };
    });

    let fullText = userText;
    const fileTexts = atts.filter((a) => a.kind === "file").map((a) => `\n\n[ATTACHED FILE: ${a.name}]\n${atobSafe(a.dataUrl)}`.slice(0, 12000));
    if (fileTexts.length) fullText += fileTexts.join("");
    if (atts.some((a) => a.kind === "audio")) fullText += `\n\n[NOTE: user attached ${atts.filter((a) => a.kind === "audio").length} audio file(s) — acknowledge and ask to use Voice Lab transcribe if needed.]`;

    const imgUrls = [...atts.filter((a) => a.kind === "image").map((a) => a.dataUrl), ...wsImages.map((f) => f.content)].slice(0, 4);
    const userMsg: any = imgUrls.length
      ? { role: "user", content: [{ type: "text", text: fullText }, ...imgUrls.map((u) => ({ type: "image_url", image_url: { url: u } }))] }
      : { role: "user", content: fullText };
    return { msgs: [sysMsg, ...hist, userMsg], imgCount: imgUrls.length };
  }, [settings.systemPrompt, settings.enableWorkspace, settings.enableCache, settings.model, workspace, model.vendor]);

  function atobSafe(dataUrl: string): string {
    try {
      if (!dataUrl.startsWith("data:")) return dataUrl.slice(0, 12000);
      const [head, b64] = dataUrl.split(",");
      if (head.includes("text") || head.includes("json") || head.includes("markdown")) return decodeURIComponent(escape(atob(b64.slice(0, 20000))));
      return `[binary ${head} — ${b64.length} chars, preview unavailable as text]`;
    } catch { return "[attachment decode failed]"; }
  }

  const buildOpts = useCallback((tools: any[]) => {
    const o: any = { model: settings.model, stream: settings.stream };
    if (checks.temperature.ok) o.temperature = settings.temperature;
    o.max_tokens = settings.max_tokens;
    if (checks.reasoning_effort.ok && settings.reasoning_effort !== "none") o.reasoning_effort = settings.reasoning_effort;
    if (checks.verbosity.ok && settings.verbosity !== "medium") o.verbosity = settings.verbosity;
    if (checks.thinking.ok) {
      if (settings.thinkingType === "enabled") o.thinking = { type: "enabled", budgetTokens: settings.thinkingBudget };
      else if (settings.thinkingType !== "adaptive") o.thinking = { type: settings.thinkingType };
      else o.thinking = { type: "adaptive" };
    }
    if (tools.length) { o.tools = tools; if (settings.toolChoice !== "auto") o.toolChoice = settings.toolChoice; o.parallelToolCalls = settings.parallelTools; }
    if (settings.stopSequences.trim()) o.stopSequences = settings.stopSequences.split(",").map((s) => s.trim()).filter(Boolean).slice(0, 4);
    if (settings.jsonMode) { try { o.outputFormat = { type: "json_schema", name: "nexus_output", strict: false, schema: JSON.parse(settings.jsonSchema) }; } catch { /* ignore */ } }
    if (settings.compaction) o.compaction = settings.compactionThreshold ? { trigger_tokens: settings.compactionThreshold } : true;
    if (settings.normalize !== null) o.normalize = settings.normalize;
    if (checks.image_config.ok) o.image_config = { aspect_ratio: settings.imageAspect, image_size: settings.imageSize };
    return o;
  }, [settings, checks]);

  // puter.chat wrapper — testMode is a positional arg in puter.js, not an option
  const callChat = useCallback(async (puter: any, conversation: any[], opts: any, stream: boolean) => {
    const o = { ...opts, stream };
    if (settings.testMode) return puter.ai.chat(conversation, true, o);
    return puter.ai.chat(conversation, o);
  }, [settings.testMode]);

  // ─── SEND ───
  const send = useCallback(async (override?: string, editId?: string) => {
    const text = (override ?? input).trim();
    if ((!text && attachments.length === 0) || streaming) return;
    let sess = sessionsRef.current.find((s) => s.id === activeId);
    if (!sess) return;
    if (editId) {
      sess = { ...sess, messages: sess.messages.filter((m) => m.id !== editId) };
      const fixed = sess;
      setSessions((p) => p.map((s) => (s.id === fixed.id ? fixed : s)));
      sessionsRef.current = sessionsRef.current.map((s) => (s.id === fixed.id ? fixed : s));
    }
    const userMsg: ChatMessage = { id: uid(), role: "user", text: text || "(attachments)", ts: Date.now(), model: settings.model, attachments: attachments.length ? [...attachments] : undefined };
    const base: ChatSession = {
      ...sess,
      model: settings.model,
      updatedAt: Date.now(),
      title: sess.messages.length === 0 ? (text.slice(0, 46) || "New conversation") : sess.title,
      messages: [...sess.messages, userMsg],
    };
    setSessions((p) => p.map((s) => (s.id === base.id ? base : s)));
    setInput(""); setAttachments([]); setView("chat");
    setStreaming(true); abortRef.current = false;
    setStreamText(""); setStreamReason(""); setStreamTools([]);

    try {
      const puter = await loadPuter();
      // auto-transcribe attached audio locally before chatting
      let enrichedText = userMsg.text;
      const auds = (userMsg.attachments || []).filter((a) => a.kind === "audio");
      if (auds.length) {
        setStreamText("Transcribing audio…");
        for (const a of auds.slice(0, 2)) {
          try {
            const r: any = await puter.ai.speech2txt(a.dataUrl, { model: "whisper-1" });
            const t = typeof r === "string" ? r : r?.text || "";
            if (t) enrichedText += `\n\n[VOICE TRANSCRIPT (${a.name})]\n${t.slice(0, 6000)}`;
          } catch { enrichedText += `\n\n[audio ${a.name} could not be transcribed]`; }
        }
        // update stored user message with transcript
        const withT = { ...base, messages: base.messages.map((m) => m.id === userMsg.id ? { ...m, text: enrichedText } : m) };
        setSessions((p) => p.map((s) => (s.id === withT.id ? withT : s)));
      }
      const tools = buildTools();
      const { msgs } = buildMessages({ ...base, messages: base.messages.map((m) => m.id === userMsg.id ? { ...m, text: enrichedText } : m) }, enrichedText, userMsg.attachments || []);
      const opts = buildOpts(tools);

      let conversation: any[] = [...msgs];
      let finalText = "", finalReason = "", allTools: ToolCallRecord[] = [], finalImages: string[] = [], finalAudio: string | undefined, finalVideo: string | undefined, compaction: any = null;
      let inTok = estimateTokens(JSON.stringify(conversation)), outTok = 0;

      for (let turn = 0; turn < 5; turn++) {
        if (abortRef.current) break;
        if (effectiveStream) {
          let turnText = "", turnReason = "";
          const pendingTools: any[] = [];
          const resp = await callChat(puter, conversation, opts, true);
          for await (const part of resp) {
            if (abortRef.current) break;
            if (!part) continue;
            if (part.type === "error" || part.error) throw new Error(part.message || part.error || "stream error");
            if (typeof part.text === "string" && part.text) { turnText += part.text; setStreamText(finalText + turnText); }
            else if (typeof part === "string") { turnText += part; setStreamText(finalText + turnText); }
            if (typeof part.reasoning === "string" && part.reasoning) { turnReason += part.reasoning; setStreamReason(finalReason + turnReason); }
            if (part.type === "compaction" || part.compaction) compaction = part.compaction || part;
            const tc = part.tool_calls || part.toolCalls || (part.type === "tool_use" ? [part] : null);
            if (tc && Array.isArray(tc) && tc.length) pendingTools.push(...tc);
            else if (part.type === "tool_use" && (part.name || part.id)) pendingTools.push(part);
            if (part.message?.tool_calls?.length) pendingTools.push(...part.message.tool_calls);
          }
          finalText += turnText; finalReason += turnReason; outTok += estimateTokens(turnText + turnReason);
          if (!pendingTools.length) break;
          if (pendingTools.length && pendingTools.every((t) => (t?.function?.name || t?.name) === "web_search")) break;
          // execute local function tools — single assistant turn + N tool results
          const turnRecs: ToolCallRecord[] = [];
          for (const raw of pendingTools) {
            const name = raw?.function?.name || raw?.name || "tool";
            if (name === "web_search") continue; // native, already executed upstream
            let args: any = {};
            try { args = typeof raw?.function?.arguments === "string" ? JSON.parse(raw.function.arguments) : raw?.input || raw?.args || {}; } catch { args = {}; }
            const t0 = performance.now();
            const result = await runLocalTool(name, args);
            const rec: ToolCallRecord = { id: raw?.id || uid(), name, args, result: String(result).slice(0, 6000), ms: Math.round(performance.now() - t0), status: "ok" };
            turnRecs.push(rec); allTools.push(rec); setStreamTools([...allTools]);
          }
          if (turnRecs.length) {
            conversation = [...conversation,
              { role: "assistant", content: turnText || "", tool_calls: turnRecs.map((r) => ({ id: r.id, type: "function", function: { name: r.name, arguments: JSON.stringify(r.args) } })) },
              ...turnRecs.map((r) => ({ role: "tool", tool_call_id: r.id, content: r.result }))];
          }
          if (turn === 4) break;
        } else {
          const res: any = await callChat(puter, conversation, opts, false);
          const msg = res?.message || res;
          const content = contentToString(msg?.content ?? msg?.text ?? res);
          finalText += (finalText ? "\n" : "") + content;
          setStreamText(finalText);
          const rs = msg?.reasoning || msg?.reasoning_content || res?.reasoning || "";
          if (rs) { finalReason += (typeof rs === "string" ? rs : JSON.stringify(rs)); setStreamReason(finalReason); }
          if (msg?.images?.length) finalImages.push(...msg.images.map((im: any) => im?.image_url?.url).filter(Boolean));
          if (res?.compaction) compaction = res.compaction;
          const tcs: any[] = msg?.tool_calls || msg?.toolCalls || res?.tool_calls || [];
          if (res?.usage) { inTok = res.usage.prompt_tokens || res.usage.input_tokens || inTok; outTok = res.usage.completion_tokens || res.usage.output_tokens || estimateTokens(finalText); }
          else outTok = estimateTokens(finalText);
          if (!tcs.length) break;
          for (const raw of tcs) {
            const name = raw?.function?.name || raw?.name;
            if (name === "web_search" || !name) continue;
            let args: any = {}; try { args = JSON.parse(raw.function.arguments); } catch { args = {}; }
            const t0 = performance.now();
            const result = await runLocalTool(name, args);
            allTools.push({ id: raw.id || uid(), name, args, result: String(result).slice(0, 6000), ms: Math.round(performance.now() - t0), status: "ok" });
            setStreamTools([...allTools]);
          }
          conversation = [...conversation, msg, ...allTools.slice(-4).map((t) => ({ role: "tool", tool_call_id: t.id, content: t.result }))];
        }
      }

      // non-stream image extraction fallback: last call may have images even in stream mode? try parse? (stream rarely returns images) — do a follow-up check only for image models
      if (!finalText && !finalImages.length && model.caps.imageGen) finalText = "(image model returned no text — check gallery / retry)";

      const assistant: ChatMessage = {
        id: uid(), role: "assistant", text: finalText || "—", reasoning: finalReason || undefined,
        images: finalImages.length ? finalImages : undefined, audioUrl: finalAudio, videoUrl: finalVideo,
        toolCalls: allTools.length ? allTools : undefined, compaction: compaction || undefined,
        usage: { in: inTok, out: outTok, total: inTok + outTok }, model: settings.model, ts: Date.now(),
      };
      updateSession(base.id, (s) => ({ ...s, updatedAt: Date.now(), messages: [...s.messages, assistant], totalIn: (s.totalIn || 0) + inTok, totalOut: (s.totalOut || 0) + outTok }));
      setUsage((u) => ({ in: u.in + inTok, out: u.out + outTok, calls: u.calls + 1 }));
      if (finalImages.length) {
        const g = store.gallery;
        store.gallery = [...finalImages.map((src) => ({ src, prompt: userMsg.text.slice(0, 120), model: settings.model, ts: Date.now(), kind: "image", id: uid() })), ...g].slice(0, 60);
      }
    } catch (e: any) {
      const msg = e?.message || e?.error || String(e);
      const assistant: ChatMessage = { id: uid(), role: "assistant", text: "", ts: Date.now(), model: settings.model, error: friendlyErr(msg) };
      updateSession(base.id, (s) => ({ ...s, messages: [...s.messages, assistant] }));
      toast("Failed: " + friendlyErr(msg).slice(0, 90));
    }
    setStreaming(false); setStreamText(""); setStreamReason(""); setStreamTools([]);
  }, [input, attachments, streaming, activeId, settings, buildTools, buildMessages, buildOpts, callChat, effectiveStream, runLocalTool, updateSession, model.caps.imageGen, toast]);

  function friendlyErr(m: string): string {
    if (/auth|sign|login|401|403/i.test(m)) return "Authentication needed — click “Connect Puter” top-right, then retry. (" + m.slice(0, 120) + ")";
    if (/insufficient|funds|402|balance|credit/i.test(m)) return "Insufficient Puter credits for this request. Try test mode, a smaller model (Luna/Nano), or shorter output. (" + m.slice(0, 120) + ")";
    if (/not found|unknown model/i.test(m)) return "Model not found on Puter right now — pick another from the model picker. (" + m.slice(0, 120) + ")";
    if (/network|fetch|timeout/i.test(m)) return "Network/timeout — retry. Long video & reasoning calls can take minutes. (" + m.slice(0, 120) + ")";
    return m.slice(0, 400);
  }

  const stop = () => { abortRef.current = true; setStreaming(false); };
  const regen = () => {
    const cur = sessionsRef.current.find((s) => s.id === activeId);
    if (!cur || streaming) return;
    const lastUser = [...cur.messages].reverse().find((m) => m.role === "user");
    if (!lastUser) return;
    const idx = cur.messages.lastIndexOf(lastUser);
    const trimmed = cur.messages.slice(0, idx);
    const next = { ...cur, messages: trimmed, updatedAt: Date.now() };
    setSessions((p) => p.map((s) => (s.id === cur.id ? next : s)));
    sessionsRef.current = sessionsRef.current.map((s) => (s.id === cur.id ? next : s));
    setAttachments(lastUser.attachments ? [...lastUser.attachments] : []);
    setTimeout(() => send(lastUser.text), 120);
  };

  // voice input
  const toggleMic = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { toast("Voice input not supported in this browser — try Chrome"); return; }
    if (listening) { recogRef.current?.stop(); setListening(false); return; }
    const r = new SR(); recogRef.current = r;
    r.lang = "en-US"; r.interimResults = true;
    r.onresult = (e: any) => { const t = Array.from(e.results).map((x: any) => x[0].transcript).join(""); setInput((p) => (p ? p + " " : "") + t); };
    r.onend = () => setListening(false);
    r.onerror = () => setListening(false);
    r.start(); setListening(true);
  };

  const speak = async (text: string) => {
    try {
      const p = await loadPuter();
      // auto-correct voice/model per provider so chat TTS never sends mismatched ids
      let voice = settings.ttsVoice, vmodel: any = settings.ttsModel;
      if (settings.ttsProvider === "openai" && !["alloy","ash","coral","echo","fable","onyx","nova","sage","shimmer","ballad","verse","marin","cedar"].includes(voice)) { voice = "alloy"; vmodel = "gpt-4o-mini-tts"; }
      if (settings.ttsProvider === "aws-polly" && voice.length > 20) voice = "Joanna";
      const a: any = await p.ai.txt2speech(text.slice(0, 1200), { provider: settings.ttsProvider, voice, model: vmodel, engine: settings.ttsProvider === "aws-polly" ? vmodel : undefined });
      new Audio(a.src).play().catch(() => {});
      toast("Playing response audio");
    } catch (e: any) { // fallback browser TTS
      try { const u = new SpeechSynthesisUtterance(text.slice(0, 800)); speechSynthesis.speak(u); toast("Browser voice (Puter TTS unavailable)"); } catch { toast("TTS failed"); }
    }
  };

  const onPickFiles = async (files: FileList | null, kind: "image" | "file" | "audio") => {
    if (!files) return;
    const list: Attachment[] = [];
    for (const f of Array.from(files).slice(0, 4)) {
      const d = await fileToDataUrl(f);
      list.push({ id: uid(), kind: kind === "image" || f.type.startsWith("image/") ? "image" : f.type.startsWith("audio/") ? "audio" : "file", name: f.name, dataUrl: kind === "file" && !f.type.startsWith("image/") ? d : d, size: f.size, mime: f.type });
    }
    setAttachments((a) => [...a, ...list].slice(0, 6));
    setAttachMenu(false);
  };

  const exportChat = (fmt: "md" | "json") => {
    if (!active) return;
    const body = fmt === "md"
      ? `# ${active.title}\n\n_Model: ${active.model} · ${new Date(active.createdAt).toLocaleString()}_\n\n` + active.messages.map((m) => `## ${m.role}\n${m.reasoning ? `<details><summary>thinking</summary>\n\n${m.reasoning}\n\n</details>\n\n` : ""}${m.text}`).join("\n\n---\n\n")
      : JSON.stringify(active, null, 2);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([body], { type: "text/plain" }));
    a.download = `nexus-${active.title.slice(0, 30).replace(/\W+/g, "-")}.${fmt}`;
    a.click(); toast("Exported ." + fmt);
  };

  const sessToks = active ? sessionTokens(active) : { inp: 0, out: 0, total: 0 };
  const ctxPct = Math.min(100, (sessToks.total / model.context) * 100);
  const estInput = estimateTokens(input);

  const liveMerged = useMemo(() => {
    if (!modelQ.trim()) return MODEL_CATALOG;
    const q = modelQ.toLowerCase();
    const stat = MODEL_CATALOG.filter((m) => (m.id + m.name + m.vendor + m.tagline).toLowerCase().includes(q));
    const live = liveModels.filter((m: any) => String(m.id || "").toLowerCase().includes(q)).slice(0, 30).map((m: any) => ({ dynamic: true, ...m }));
    return [...stat, ...live];
  }, [modelQ, liveModels]);

  const dark = settings.theme === "dark";

  return (
    <div className={cn("flex h-full overflow-hidden", dark ? "bg-[#09090b] text-zinc-100" : "bg-[#fafafa] text-zinc-900")} style={{ fontSize: settings.fontSize }}>
      <LeftSidebar open={sideOpen} onClose={() => setSideOpen(false)} sessions={sessions} activeId={activeId}
        onSelect={(id) => { setActiveId(id); const s = sessionsRef.current.find((x) => x.id === id); if (s?.model) setSettings((prev) => ({ ...prev, model: s.model })); }} onNew={newChat}
        onDelete={(id) => { setSessions((p) => p.filter((s) => s.id !== id)); if (activeId === id) setActiveId(sessions.find((s) => s.id !== id)?.id ?? null); }}
        onPin={(id) => setSessions((p) => p.map((s) => (s.id === id ? { ...s, pinned: !s.pinned } : s)))}
        onRename={(id, t) => setSessions((p) => p.map((s) => (s.id === id ? { ...s, title: t } : s)))}
        view={view} setView={setView} onOpenSettings={() => setSetOpen(true)} onOpenWorkspace={() => setWsOpen(true)}
        authed={authed} user={user} onAuth={doAuth} usage={usage} />

      {/* ─── MAIN ─── */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* top bar */}
        <header className={cn("z-20 flex items-center gap-1.5 border-b px-3 py-2.5", dark ? "border-white/10 bg-[#09090b]/85 backdrop-blur-xl" : "border-black/10 bg-white/85 backdrop-blur-xl")}>
          <button onClick={() => setSideOpen(true)} className="grid h-8 w-8 place-items-center rounded-lg hover:bg-black/5 lg:hidden dark:hover:bg-white/10"><Menu size={17} /></button>
          {view === "chat" ? (
            <>
              <button onClick={() => setModelOpen(true)} className={cn("group flex min-w-0 items-center gap-2 rounded-xl border px-2.5 py-1.5 text-left transition", dark ? "border-white/10 bg-white/[.05] hover:bg-white/10" : "border-black/10 bg-black/[.03] hover:bg-black/[.06]")}>
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-[11px] font-bold text-white" style={{ background: model.color === "#e5e5e5" || model.color === "#d4d4d8" ? "#27272a" : model.color }}>{model.name[0]}</span>
                <span className="min-w-0 leading-tight">
                  <span className="block truncate text-[13px] font-semibold">{model.name} <span className="font-normal opacity-50">· {model.vendor}</span></span>
                  <span className="block truncate text-[10.5px] opacity-50">{model.tagline}</span>
                </span>
                <ChevronDown size={14} className="shrink-0 opacity-50" />
              </button>
              <div className="ml-1 hidden items-center gap-1.5 md:flex">
                {model.caps.reasoning && <Chip tone="violet"><Brain size={10} /> reasoning</Chip>}
                {model.caps.webSearch && settings.enableWebSearch && <Chip tone="amber"><Globe size={10} /> web</Chip>}
                {settings.testMode && <Chip tone="amber"><FlaskConical size={10} /> test</Chip>}
                {!checks.temperature.ok && <Chip tone="amber">temp omitted</Chip>}
              </div>
              <span className="mx-1 hidden text-[11px] tabular-nums text-zinc-400 sm:block">{(sessToks.total / 1000).toFixed(1)}k / {(model.context / 1000).toFixed(0)}k</span>
            </>
          ) : (
            <p className="text-[13px] font-bold">{view === "image" ? "Image Lab" : view === "video" ? "Video Lab" : "Voice & OCR Lab"}</p>
          )}
          <span className="flex-1" />
          {puterOk === false && <Chip tone="red"><CircleAlert size={10} /> puter blocked</Chip>}
          {view === "chat" && active && (
            <span className="hidden items-center gap-0.5 sm:flex">
              <IconBtn title="Export .md" onClick={() => exportChat("md")}><Download size={15} /></IconBtn>
              <IconBtn title="New chat" onClick={newChat}><Plus size={16} /></IconBtn>
              <IconBtn title="Workspace" onClick={() => setWsOpen(true)} active={wsOpen}><FolderOpen size={15} /></IconBtn>
              <IconBtn title="Parameters" onClick={() => setSetOpen(true)} active={setOpen}><Settings2 size={15} /></IconBtn>
            </span>
          )}
          <button onClick={doAuth} className={cn("flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-xs font-semibold", authed ? (dark ? "bg-emerald-500/15 text-emerald-300" : "bg-emerald-500/10 text-emerald-700") : (dark ? "bg-white text-black" : "bg-black text-white"))}>
            <span className={cn("h-1.5 w-1.5 rounded-full", authed ? "bg-emerald-500" : "bg-current opacity-50")} />{authed ? (user?.username || "Connected") : "Connect Puter"}
          </button>
        </header>

        {/* context bar */}
        {view === "chat" && active && active.messages.length > 0 && settings.showTokens && (
          <div className={cn("flex items-center gap-2 border-b px-4 py-1.5 text-[10.5px] text-zinc-400", dark ? "border-white/[.07]" : "border-black/[.07]")}>
            <Zap size={11} /><span>context {ctxPct.toFixed(1)}% · in {(sessToks.inp / 1000).toFixed(1)}k · out {(sessToks.out / 1000).toFixed(1)}k</span>
            <div className="w-28"><Meter value={sessToks.total} max={model.context} tone={ctxPct > 85 ? "bg-red-500" : ctxPct > 60 ? "bg-amber-500" : dark ? "bg-white" : "bg-zinc-900"} /></div>
            {settings.compaction && <span>· compaction @ {(settings.compactionThreshold / 1000).toFixed(0)}k</span>}
            {settings.enableCache && <span className="text-emerald-500">· cache on</span>}
          </div>
        )}

        {/* content */}
        {view !== "chat" ? (
          <div className="flex-1 overflow-y-auto">
            {view === "image" && <ImageLab onToast={toast} />}
            {view === "video" && <VideoLab onToast={toast} />}
            {view === "audio" && <VoiceLab onToast={toast} />}
          </div>
        ) : !active || active.messages.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center overflow-y-auto px-4">
            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-2xl text-center">
              <div className="mx-auto mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-black text-white shadow-xl dark:bg-white dark:text-black">
                <svg width="26" height="26" viewBox="0 0 32 32" fill="none"><path d="M9 9l14 14M23 9L9 23" stroke="currentColor" strokeWidth="3" strokeLinecap="round" /><circle cx="16" cy="16" r="3.5" fill="currentColor" /></svg>
              </div>
              <h1 className="font-serif text-[34px] italic leading-tight tracking-tight">What should we explore?</h1>
              <p className="mt-1.5 text-[13px] text-zinc-500 dark:text-zinc-400">500+ models via Puter.js · files stay on this device · {liveModels.length > 0 ? `${liveModels.length} live models detected` : "connect Puter to unlock live catalog"}</p>
              <div className="mt-6 grid grid-cols-2 gap-2 text-left sm:grid-cols-3">
                {PROMPT_STARTERS.map((s) => (
                  <button key={s.title} onClick={() => {
                    if (s.image) { setView("image"); }
                    else if ((s as any).tts) { setView("audio"); }
                    else { setInput(s.prompt); taRef.current?.focus(); }
                  }} className={cn("group rounded-2xl border p-3 text-left transition hover:-translate-y-0.5", dark ? "border-white/10 bg-white/[.04] hover:bg-white/[.08]" : "border-black/10 bg-white hover:shadow-lg")}>
                    <span className="text-lg">{s.icon}</span>
                    <p className="mt-1 text-[12.5px] font-semibold">{s.title}</p>
                    <p className="mt-0.5 line-clamp-2 text-[11px] leading-snug opacity-50">{s.prompt.slice(0, 80)}…</p>
                  </button>
                ))}
              </div>
              {!authed && (
                <button onClick={doAuth} className={cn("mx-auto mt-5 flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold", dark ? "bg-white text-black" : "bg-black text-white")}>
                  <Sparkles size={13} /> Connect Puter to start chatting — free, no API keys
                </button>
              )}
            </motion.div>
          </div>
        ) : (
          <div ref={scrollRef} className="flex-1 overflow-y-auto">
            <div className="mx-auto w-full max-w-3xl space-y-5 px-4 py-6 pb-10">
              {active.messages.map((m, i) => {
                const isLast = i === active.messages.length - 1;
                if (m.role === "user") return (
                  <motion.div key={m.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="group flex justify-end">
                    <div className="max-w-[85%]">
                      {m.attachments && m.attachments.length > 0 && <div className="mb-1.5 flex justify-end"><AttachmentThumbs atts={m.attachments} /></div>}
                      <div className={cn("whitespace-pre-wrap rounded-2xl rounded-br-md px-4 py-2.5 text-[14px] leading-relaxed", dark ? "bg-white/[.1]" : "bg-black/[.06]")}>{m.text}</div>
                      <div className="mt-1 flex items-center justify-end gap-1"><span className="mr-1 text-[10px] text-zinc-400">{timeAgo(m.ts)}</span>
                        <MsgActions m={m} copied={copiedId === m.id} isLast={false}
                          onCopy={() => { navigator.clipboard.writeText(m.text); setCopiedId(m.id); setTimeout(() => setCopiedId(null), 1200); }}
                          onEdit={() => { setInput(m.text); updateSession(active.id, (s) => ({ ...s, messages: s.messages.filter((x) => x.id !== m.id) })); }}
                          onDelete={() => updateSession(active.id, (s) => ({ ...s, messages: s.messages.filter((x) => x.id !== m.id) }))} /></div>
                    </div>
                  </motion.div>
                );
                return (
                  <motion.div key={m.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="group">
                    <div className="mb-1.5 flex items-center gap-1.5">
                      <span className="grid h-5 w-5 place-items-center rounded-md text-[10px] font-bold text-white" style={{ background: model.color === "#e5e5e5" ? "#27272a" : model.color }}>N</span>
                      <span className="text-[11px] font-medium text-zinc-400">{m.model ? getModel(m.model).name : model.name} · {timeAgo(m.ts)}</span>
                      {m.usage && settings.showTokens && <span className="font-mono text-[10px] text-zinc-500">↑{m.usage.in} ↓{m.usage.out}</span>}
                    </div>
                    {m.error ? <ErrorCard msg={m.error} /> : (
                      <div className="space-y-2.5">
                        {settings.showThinking && m.reasoning && <Thinking text={m.reasoning} />}
                        {settings.showTools && m.toolCalls?.length ? <ToolTray tools={m.toolCalls} /> : null}
                        {m.text && m.text !== "—" && <Md text={m.text} />}
                        {m.images?.map((src, k) => (
                          <a key={k} href={src} target="_blank" rel="noreferrer" className="block overflow-hidden rounded-2xl border border-black/10 dark:border-white/10">
                            <img src={src} alt="generated" className="max-h-[480px] w-full object-contain bg-black/5 dark:bg-white/5" />
                          </a>
                        ))}
                      </div>
                    )}
                    {!m.error && (
                      <div className="mt-1"><MsgActions m={m} copied={copiedId === m.id} isLast={isLast && !streaming}
                        onCopy={() => { navigator.clipboard.writeText(m.text); setCopiedId(m.id); setTimeout(() => setCopiedId(null), 1200); }}
                        onSpeak={() => speak(m.text)} onRegen={regen} /></div>
                    )}
                  </motion.div>
                );
              })}
              {streaming && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2.5">
                  <div className="flex items-center gap-1.5"><span className="grid h-5 w-5 animate-pulse place-items-center rounded-md bg-black text-[10px] font-bold text-white dark:bg-white dark:text-black">N</span><span className="text-[11px] text-zinc-400">{model.name} is writing…</span></div>
                  {settings.showThinking && streamReason && <Thinking text={streamReason} streaming />}
                  {settings.showTools && streamTools.length > 0 && <ToolTray tools={streamTools} />}
                  {streamText ? <Md text={streamText + "▍"} /> : <TypingDots />}
                </motion.div>
              )}
            </div>
          </div>
        )}

        {/* ─── COMPOSER ─── */}
        {view === "chat" && (
          <div className={cn("border-t px-3 pb-3 pt-2", dark ? "border-white/10" : "border-black/10")}>
            <div className="mx-auto w-full max-w-3xl">
              <AnimatePresence>
                {attachments.length > 0 && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="mb-2 flex flex-wrap gap-2 overflow-hidden">
                    {attachments.map((a) => (
                      <span key={a.id} className={cn("flex items-center gap-1.5 rounded-xl border py-1 pl-1 pr-2 text-xs", dark ? "border-white/10 bg-white/[.06]" : "border-black/10 bg-white")}>
                        {a.kind === "image" ? <img src={a.dataUrl} className="h-8 w-8 rounded-lg object-cover" alt="" /> : a.kind === "audio" ? <Mic size={13} /> : <FileText size={13} />}
                        <span className="max-w-[120px] truncate">{a.name}</span>
                        <button onClick={() => setAttachments((x) => x.filter((y) => y.id !== a.id))}><X size={12} /></button>
                      </span>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
              <div className={cn("composer-glow rounded-2xl border transition", dark ? "border-white/12 bg-[#141417]" : "border-black/10 bg-white shadow-sm")}>
                <textarea ref={taRef} value={input} onChange={(e) => setInput(e.target.value)} rows={1}
                  onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && settings.enterToSend) { e.preventDefault(); send(); } }}
                  placeholder={`Message ${model.name}…  (⇧↵ newline · /image /video /speech shortcuts)`}
                  className="autogrow max-h-44 w-full resize-none bg-transparent px-4 pb-1 pt-3 text-[14px] outline-none placeholder:text-zinc-400" />
                <div className="flex items-center gap-0.5 px-2 pb-2">
                  <div className="relative">
                    <IconBtn title="Attach" onClick={() => setAttachMenu(!attachMenu)} active={attachMenu}><Paperclip size={16} /></IconBtn>
                    <AnimatePresence>
                      {attachMenu && (
                        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }} className={cn("absolute bottom-10 left-0 z-30 w-52 overflow-hidden rounded-xl border p-1 shadow-xl", dark ? "border-white/10 bg-[#1a1a1e]" : "border-black/10 bg-white")}>
                          {[{ t: "Photo / image", i: <ImageIcon size={14} />, f: () => imgIn.current?.click() }, { t: "Document / text", i: <FileText size={14} />, f: () => fileIn.current?.click() }, { t: "Audio (auto-transcribe)", i: <Mic size={14} />, f: () => audIn.current?.click() }, { t: "Workspace files", i: <FolderOpen size={14} />, f: () => { setWsOpen(true); setAttachMenu(false); } }, { t: "Generate image…", i: <Sparkles size={14} />, f: () => { setView("image"); setAttachMenu(false); } }].map((b) => (
                            <button key={b.t} onClick={b.f} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-[13px] hover:bg-black/5 dark:hover:bg-white/10">{b.i}{b.t}</button>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  <IconBtn title="Voice input" onClick={toggleMic} active={listening}><Mic size={16} /></IconBtn>
                  <IconBtn title="Parameters" onClick={() => setSetOpen(true)}><Settings2 size={16} /></IconBtn>
                  <span className="ml-1 hidden font-mono text-[10.5px] text-zinc-400 sm:block">{estInput > 0 ? `~${estInput} tok` : ""}{workspace.filter((f) => f.attach).length > 0 ? ` · 📎${workspace.filter((f) => f.attach).length}` : ""}{buildTools().length > 0 ? ` · 🛠${buildTools().length}` : ""}</span>
                  <span className="flex-1" />
                  {streaming ? (
                    <button onClick={stop} className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-500 text-white"><Square size={14} /></button>
                  ) : (
                    <button onClick={() => {
                      const t = input.trim();
                      if (t.startsWith("/image")) { setView("image"); }
                      else if (t.startsWith("/video")) { setView("video"); }
                      else if (t.startsWith("/speech") || t.startsWith("/voice")) { setView("audio"); }
                      else if (t.startsWith("/clear")) { setInput(""); newChat(); }
                      else send();
                    }} disabled={!input.trim() && attachments.length === 0} className={cn("flex h-9 w-9 items-center justify-center rounded-xl transition", (!input.trim() && attachments.length === 0) ? "bg-black/10 text-zinc-400 dark:bg-white/10" : "bg-black text-white hover:scale-105 dark:bg-white dark:text-black")}>
                      <ArrowUp size={17} strokeWidth={2.5} />
                    </button>
                  )}
                </div>
              </div>
              <p className="mt-1.5 text-center text-[10.5px] text-zinc-400">Runs on Puter.js · saved locally only · <button className="underline" onClick={() => setSetOpen(true)}>temp {checks.temperature.ok ? settings.temperature : "n/a"} · {settings.reasoning_effort} · {settings.model}</button> · <button className="underline" onClick={() => setConfirmClear(true)}>clear all data</button></p>
            </div>
          </div>
        )}
      </div>

      {/* drawers & modals */}
      <AnimatePresence>{setOpen && <SettingsDrawer open={setOpen} onClose={() => setSetOpen(false)} settings={settings} onChange={setSettings} liveCount={liveModels.length} />}</AnimatePresence>
      <AnimatePresence>{wsOpen && <WorkspaceDrawer open={wsOpen} onClose={() => setWsOpen(false)} files={workspace} onChange={setWorkspace} onToast={toast} />}</AnimatePresence>

      {/* model picker */}
      <AnimatePresence>
        {modelOpen && (
          <ModalShell onClose={() => setModelOpen(false)}>
            <div className="p-4">
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold">Choose model</h2><Chip tone="blue">{MODEL_CATALOG.length} curated{liveModels.length ? ` + ${liveModels.length} live` : ""}</Chip>
                <span className="flex-1" /><button onClick={() => setModelOpen(false)}><X size={16} /></button>
              </div>
              <input autoFocus value={modelQ} onChange={(e) => setModelQ(e.target.value)} placeholder="Search gpt, claude, gemini, grok, llama…" className="mt-3 w-full rounded-xl border border-black/10 bg-black/[.03] p-2.5 text-[13px] outline-none dark:border-white/10 dark:bg-white/[.05]" />
              <div className="mt-2 max-h-[52vh] space-y-1 overflow-y-auto pr-1">
                {liveMerged.slice(0, 60).map((m: any) => {
                  if (m.dynamic) {
                    const sel = settings.model === m.id;
                    return (
                      <button key={m.id} onClick={() => { setSettings({ ...settings, model: m.id }); setModelOpen(false); if (active) updateSession(active.id, (s) => ({ ...s, model: m.id })); }} className={cn("flex w-full items-center gap-2.5 rounded-xl border p-2.5 text-left", sel ? "border-black bg-black/[.04] dark:border-white dark:bg-white/[.08]" : "border-transparent hover:bg-black/[.04] dark:hover:bg-white/[.06]")}>
                        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-zinc-500 text-xs font-bold text-white">✦</span>
                        <span className="min-w-0 flex-1"><span className="block truncate text-[13px] font-semibold">{m.id}</span><span className="block truncate text-[11px] opacity-50">{m.provider || "live"} · ctx {m.context ? (m.context / 1000).toFixed(0) + "k" : "?"}</span></span>
                        {sel && <Check size={15} />}
                      </button>
                    );
                  }
                  const mm = m as typeof MODEL_CATALOG[number];
                  const sel = settings.model === mm.id;
                  return (
                    <button key={mm.id} onClick={() => { setSettings({ ...settings, model: mm.id }); setModelOpen(false); if (active) updateSession(active.id, (s) => ({ ...s, model: mm.id })); toast(`Model → ${mm.name}`); }} className={cn("flex w-full items-center gap-2.5 rounded-xl border p-2.5 text-left", sel ? "border-black bg-black/[.04] dark:border-white dark:bg-white/[.08]" : "border-transparent hover:bg-black/[.04] dark:hover:bg-white/[.06]")}>
                      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-xs font-bold text-white" style={{ background: mm.color === "#e5e5e5" ? "#27272a" : mm.color }}>{mm.name[0]}</span>
                      <span className="min-w-0 flex-1"><span className="block truncate text-[13px] font-semibold">{mm.name} <span className="font-normal opacity-40">· {mm.vendor}</span></span><span className="block truncate text-[11px] opacity-50">{mm.tagline}</span></span>
                      <span className="flex shrink-0 gap-0.5">{"●".repeat(mm.quality).split("").map((_, i) => <span key={i} className="h-1 w-3 rounded-full bg-current opacity-70" />)}</span>
                      {sel && <Check size={15} />}
                    </button>
                  );
                })}
              </div>
            </div>
          </ModalShell>
        )}
      </AnimatePresence>

      {/* clear confirm */}
      <AnimatePresence>
        {confirmClear && (
          <ModalShell onClose={() => setConfirmClear(false)}>
            <div className="p-5 text-center">
              <Trash2 size={22} className="mx-auto text-red-500" />
              <h2 className="mt-2 text-sm font-bold">Erase all local data?</h2>
              <p className="mt-1 text-[13px] text-zinc-500">Chats, workspace, gallery, usage. This cannot be undone.</p>
              <div className="mt-4 flex gap-2">
                <button onClick={() => setConfirmClear(false)} className="flex-1 rounded-xl border border-black/10 py-2.5 text-sm dark:border-white/10">Keep</button>
                <button onClick={() => { store.clearAll(); setSessions([]); setWorkspace([]); setUsage({ in: 0, out: 0, calls: 0 }); setConfirmClear(false); newChat(); toast("All local data cleared"); }} className="flex-1 rounded-xl bg-red-500 py-2.5 text-sm font-semibold text-white">Erase everything</button>
              </div>
            </div>
          </ModalShell>
        )}
      </AnimatePresence>

      {/* toasts */}
      <div className="pointer-events-none fixed bottom-6 left-1/2 z-[80] flex -translate-x-1/2 flex-col items-center gap-2">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div key={t.id} initial={{ opacity: 0, y: 12, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8 }} className={cn("pointer-events-auto flex items-center gap-2 rounded-full px-4 py-2 text-[12.5px] font-medium shadow-xl", dark ? "bg-white text-black" : "bg-black text-white")}><Zap size={13} />{t.msg}</motion.div>
          ))}
        </AnimatePresence>
      </div>

      <input ref={imgIn} type="file" accept="image/*" multiple className="hidden" onChange={(e) => { onPickFiles(e.target.files, "image"); e.target.value = ""; }} />
      <input ref={fileIn} type="file" accept=".txt,.md,.json,.csv,.pdf,.doc,.docx,text/*" multiple className="hidden" onChange={(e) => { onPickFiles(e.target.files, "file"); e.target.value = ""; }} />
      <input ref={audIn} type="file" accept="audio/*,video/*" multiple className="hidden" onChange={(e) => { onPickFiles(e.target.files, "audio"); e.target.value = ""; }} />
    </div>
  );
}
