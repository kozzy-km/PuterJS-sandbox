import { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, Wrench, Copy, Check, Volume2, ChevronDown, AlertTriangle, Image as ImageIcon, RefreshCw, Pencil, Trash2 } from "lucide-react";
import type { ChatMessage } from "../lib/store";
import { cn } from "../utils/cn";

function CodeBlock({ lang, code }: { lang: string; code: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="overflow-hidden rounded-xl">
      <div className="codeblock-head">
        <span>{lang || "code"}</span>
        <button className="flex items-center gap-1 hover:text-white" onClick={() => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 1400); }}>
          {copied ? <Check size={12} /> : <Copy size={12} />}{copied ? "copied" : "copy"}
        </button>
      </div>
      <pre className="!m-0 !rounded-none !border-0"><code>{code}</code></pre>
    </div>
  );
}

export function Md({ text }: { text: string }) {
  return (
    <div className="md-body">
      <ReactMarkdown remarkPlugins={[remarkGfm]} components={{
        pre: ({ children }) => <>{children}</>,
        code: ({ className, children }: any) => {
          const raw = String(children ?? "");
          const isBlock = raw.includes("\n") || (className?.includes("language-"));
          if (!isBlock) return <code className={className}>{children}</code>;
          const lang = (className || "").replace("language-", "");
          return <CodeBlock lang={lang} code={raw.replace(/\n$/, "")} />;
        },
      }}>{text || ""}</ReactMarkdown>
    </div>
  );
}

export function Thinking({ text, streaming }: { text: string; streaming?: boolean }) {
  const [open, setOpen] = useState(false);
  if (!text) return null;
  return (
    <div className="overflow-hidden rounded-xl border border-violet-500/20 bg-violet-500/[.06]">
      <button onClick={() => setOpen(!open)} className="flex w-full items-center gap-2 px-3 py-2 text-left">
        <span className="relative flex h-5 w-5 items-center justify-center">
          <Brain size={14} className="text-violet-500" />
          {streaming && <span className="absolute inset-0 animate-ping rounded-full bg-violet-500/20" />}
        </span>
        <span className="text-xs font-semibold text-violet-600 dark:text-violet-300">{streaming ? "Thinking…" : "Thought process"}</span>
        <span className="ml-auto text-[10px] text-zinc-400">{text.length} chars</span>
        <ChevronDown size={14} className={cn("text-zinc-400 transition-transform", open && "rotate-180")} />
      </button>
      {streaming && !open && (
        <div className="thinking-track mx-3 mb-2 h-[3px] rounded-full bg-violet-500/15" />
      )}
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="max-h-64 overflow-y-auto whitespace-pre-wrap px-3 pb-3 font-mono text-[11.5px] leading-relaxed text-zinc-500 dark:text-zinc-400">{text}{streaming && <span className="animate-pulse">▍</span>}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function ToolTray({ tools }: { tools: NonNullable<ChatMessage["toolCalls"]> }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="overflow-hidden rounded-xl border border-sky-500/20 bg-sky-500/[.05]">
      <button onClick={() => setOpen(!open)} className="flex w-full items-center gap-2 px-3 py-2 text-left">
        <Wrench size={14} className="text-sky-500" />
        <span className="text-xs font-semibold text-sky-600 dark:text-sky-300">{tools.length} tool call{tools.length > 1 ? "s" : ""}</span>
        <ChevronDown size={14} className={cn("ml-auto text-zinc-400 transition-transform", open && "rotate-180")} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="space-y-1.5 px-3 pb-3">
              {tools.map((t) => (
                <div key={t.id} className="rounded-lg bg-black/[.04] p-2.5 text-xs dark:bg-white/[.06]">
                  <div className="flex items-center gap-2 font-mono">
                    <span className={cn("h-1.5 w-1.5 rounded-full", t.status === "ok" ? "bg-emerald-500" : "bg-red-500")} />
                    <span className="font-semibold">{t.name}</span>
                    <span className="ml-auto text-[10px] text-zinc-400">{t.ms}ms</span>
                  </div>
                  <div className="mt-1 truncate font-mono text-[10.5px] text-zinc-500">{JSON.stringify(t.args)}</div>
                  <div className="mt-1 line-clamp-3 whitespace-pre-wrap text-[11px] leading-relaxed opacity-80">{t.result}</div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function MsgActions({ m, onCopy, copied, onSpeak, onRegen, onEdit, onDelete, isLast }: any) {
  return (
    <div className="flex items-center gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
      <button title="Copy" onClick={onCopy} className="grid h-7 w-7 place-items-center rounded-md text-zinc-400 hover:bg-black/5 hover:text-zinc-800 dark:hover:bg-white/10 dark:hover:text-white">{copied ? <Check size={13} className="text-emerald-500" /> : <Copy size={13} />}</button>
      {m.role === "assistant" && (
        <>
          <button title="Read aloud" onClick={onSpeak} className="grid h-7 w-7 place-items-center rounded-md text-zinc-400 hover:bg-black/5 hover:text-zinc-800 dark:hover:bg-white/10 dark:hover:text-white"><Volume2 size={13} /></button>
          {isLast && <button title="Regenerate" onClick={onRegen} className="grid h-7 w-7 place-items-center rounded-md text-zinc-400 hover:bg-black/5 hover:text-zinc-800 dark:hover:bg-white/10 dark:hover:text-white"><RefreshCw size={13} /></button>}
        </>
      )}
      {m.role === "user" && (
        <>
          <button title="Edit & resend" onClick={onEdit} className="grid h-7 w-7 place-items-center rounded-md text-zinc-400 hover:bg-black/5 hover:text-zinc-800 dark:hover:bg-white/10 dark:hover:text-white"><Pencil size={13} /></button>
          <button title="Delete" onClick={onDelete} className="grid h-7 w-7 place-items-center rounded-md text-zinc-400 hover:bg-red-500/10 hover:text-red-500"><Trash2 size={13} /></button>
        </>
      )}
    </div>
  );
}

export function TypingDots() {
  return (
    <span className="inline-flex items-center gap-1 py-1">
      {[0, 1, 2].map((i) => <span key={i} className="h-1.5 w-1.5 rounded-full bg-zinc-400" style={{ animation: `pulse-dot 1.2s ${i * 0.18}s infinite` }} />)}
    </span>
  );
}

export function AttachmentThumbs({ atts }: { atts: NonNullable<ChatMessage["attachments"]> }) {
  return (
    <div className="flex flex-wrap gap-2">
      {atts.map((a) => a.kind === "image" ? (
        <a key={a.id} href={a.dataUrl} target="_blank" rel="noreferrer"><img src={a.dataUrl} alt={a.name} className="h-20 w-20 rounded-xl border border-black/10 object-cover dark:border-white/10" /></a>
      ) : (
        <div key={a.id} className="flex items-center gap-2 rounded-xl border border-black/10 bg-black/[.03] px-2.5 py-2 text-xs dark:border-white/10 dark:bg-white/[.05]">
          <ImageIcon size={14} /><span className="max-w-[140px] truncate">{a.name}</span>
        </div>
      ))}
    </div>
  );
}

export function ErrorCard({ msg }: { msg: string }) {
  return (
    <div className="flex items-start gap-2 rounded-xl border border-red-500/25 bg-red-500/[.07] p-3 text-[13px] text-red-600 dark:text-red-300">
      <AlertTriangle size={15} className="mt-0.5 shrink-0" />
      <div><p className="font-semibold">Request failed</p><p className="mt-0.5 opacity-90">{msg}</p>
        <p className="mt-1 text-[11px] opacity-70">Tip: sign in to Puter (top-right), try test mode off/on, or switch to gpt-5.4-nano.</p></div>
    </div>
  );
}
