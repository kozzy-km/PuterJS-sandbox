import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, Plus, Pin, Trash2, Image as ImageIcon, Clapperboard, AudioLines, MessageSquare, X, Settings2, FolderOpen, FileText, Paperclip, Download, Upload, Sun, Moon } from "lucide-react";
import type { ChatSession, WorkspaceFile, AppSettings } from "../lib/store";
import { timeAgo, sessionTokens, SYSTEM_PRESETS, store, uid, fileToDataUrl } from "../lib/store";
import { MODEL_CATALOG, getModel, checkParams, IMAGE_MODELS, VIDEO_MODELS, TTS_PRESETS } from "../lib/puter";
import { Field, Seg, Slider, Toggle, Chip, Meter } from "./ui";
import { cn } from "../utils/cn";

// ─── LEFT ───
export function LeftSidebar(p: {
  open: boolean; onClose: () => void;
  sessions: ChatSession[]; activeId: string | null;
  onSelect: (id: string) => void; onNew: () => void;
  onDelete: (id: string) => void; onPin: (id: string) => void; onRename: (id: string, t: string) => void;
  view: string; setView: (v: any) => void;
  onOpenSettings: () => void; onOpenWorkspace: () => void;
  authed: boolean; user: any; onAuth: () => void;
  usage: { in: number; out: number; calls: number };
}) {
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [et, setEt] = useState("");
  const filtered = useMemo(() => {
    const list = [...p.sessions].sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || b.updatedAt - a.updatedAt);
    if (!q.trim()) return list;
    return list.filter((s) => s.title.toLowerCase().includes(q.toLowerCase()) || s.messages.some((m) => m.text.toLowerCase().includes(q.toLowerCase())));
  }, [p.sessions, q]);

  const nav = [
    { v: "chat", label: "Chat", icon: <MessageSquare size={15} /> },
    { v: "image", label: "Image Lab", icon: <ImageIcon size={15} /> },
    { v: "video", label: "Video Lab", icon: <Clapperboard size={15} /> },
    { v: "audio", label: "Voice & OCR", icon: <AudioLines size={15} /> },
  ];

  const body = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-3 pt-4">
        <div className="grid h-8 w-8 place-items-center rounded-[10px] bg-black text-white dark:bg-white dark:text-black">
          <svg width="16" height="16" viewBox="0 0 32 32" fill="none"><path d="M9 9l14 14M23 9L9 23" stroke="currentColor" strokeWidth="3" strokeLinecap="round" /><circle cx="16" cy="16" r="3.5" fill="currentColor" /></svg>
        </div>
        <div className="leading-tight"><p className="text-[13px] font-bold tracking-tight">NEXUS</p><p className="text-[10px] text-zinc-400">local-first · puter.js</p></div>
        <button onClick={p.onClose} className="ml-auto grid h-7 w-7 place-items-center rounded-lg text-zinc-400 hover:bg-black/5 lg:hidden dark:hover:bg-white/10"><X size={15} /></button>
      </div>

      <div className="grid grid-cols-4 gap-1 px-3 pt-3">
        {nav.map((n) => (
          <button key={n.v} onClick={() => { p.setView(n.v); p.onClose(); }} title={n.label}
            className={cn("flex flex-col items-center gap-1 rounded-xl py-2 text-[10px] font-medium transition",
              p.view === n.v ? "bg-black text-white dark:bg-white dark:text-black" : "text-zinc-500 hover:bg-black/5 dark:text-zinc-400 dark:hover:bg-white/10")}>
            {n.icon}{n.label.split(" ")[0]}
          </button>
        ))}
      </div>

      <div className="px-3 pt-3">
        <button onClick={p.onNew} className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-black/10 bg-black/[.03] py-2.5 text-[13px] font-semibold hover:bg-black hover:text-white dark:border-white/15 dark:bg-white/[.06] dark:hover:bg-white dark:hover:text-black"><Plus size={15} /> New chat</button>
        <div className="relative mt-2">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search chats…" className="w-full rounded-xl border border-transparent bg-black/[.04] py-2 pl-8 pr-3 text-[13px] outline-none focus:border-black/15 dark:bg-white/[.06] dark:focus:border-white/20" />
        </div>
      </div>

      <div className="mt-2 flex-1 space-y-0.5 overflow-y-auto px-2 pb-2">
        {filtered.length === 0 && <p className="px-3 py-6 text-center text-xs text-zinc-400">No conversations yet.<br />Start one above.</p>}
        {filtered.map((s) => {
          const t = sessionTokens(s);
          const active = s.id === p.activeId;
          return (
            <div key={s.id} onClick={() => { p.onSelect(s.id); p.setView("chat"); }} className={cn("group cursor-pointer rounded-xl px-2.5 py-2 transition", active ? "bg-black/[.06] dark:bg-white/[.09]" : "hover:bg-black/[.04] dark:hover:bg-white/[.05]")}>
              <div className="flex items-center gap-1.5">
                {s.pinned && <Pin size={11} className="shrink-0 text-amber-500" />}
                {editing === s.id ? (
                  <input autoFocus value={et} onChange={(e) => setEt(e.target.value)} onBlur={() => { p.onRename(s.id, et || s.title); setEditing(null); }} onKeyDown={(e) => { if (e.key === "Enter") { p.onRename(s.id, et || s.title); setEditing(null); } }} onClick={(e) => e.stopPropagation()} className="w-full rounded-md border border-black/15 bg-white px-1.5 py-0.5 text-[13px] dark:border-white/20 dark:bg-black" />
                ) : (
                  <p onDoubleClick={(e) => { e.stopPropagation(); setEditing(s.id); setEt(s.title); }} className="flex-1 truncate text-[13px] font-medium">{s.title}</p>
                )}
                <span className="flex shrink-0 items-center gap-0.5 opacity-0 transition group-hover:opacity-100">
                  <button title={s.pinned ? "Unpin" : "Pin"} onClick={(e) => { e.stopPropagation(); p.onPin(s.id); }} className="grid h-6 w-6 place-items-center rounded-md text-zinc-400 hover:bg-black/10 hover:text-zinc-800 dark:hover:bg-white/10 dark:hover:text-white"><Pin size={12} /></button>
                  <button title="Delete" onClick={(e) => { e.stopPropagation(); p.onDelete(s.id); }} className="grid h-6 w-6 place-items-center rounded-md text-zinc-400 hover:bg-red-500/10 hover:text-red-500"><Trash2 size={12} /></button>
                </span>
              </div>
              <p className="mt-0.5 truncate text-[11px] text-zinc-400">{timeAgo(s.updatedAt)} · {getModel(s.model).name} · {(t.total / 1000).toFixed(1)}k tok</p>
            </div>
          );
        })}
      </div>

      <div className="space-y-2 border-t border-black/10 p-3 dark:border-white/10">
        <div className="rounded-xl bg-black/[.03] p-2.5 dark:bg-white/[.05]">
          <div className="flex justify-between text-[10.5px] font-medium text-zinc-500 dark:text-zinc-400"><span>Session tokens</span><span>{((p.usage.in + p.usage.out) / 1000).toFixed(1)}k · {p.usage.calls} calls</span></div>
          <div className="mt-1.5"><Meter value={p.usage.in + p.usage.out} max={500000} /></div>
        </div>
        <div className="flex gap-1.5">
          <button onClick={p.onOpenWorkspace} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-black/10 py-2 text-xs font-medium hover:bg-black/5 dark:border-white/10 dark:hover:bg-white/5"><FolderOpen size={13} /> Files</button>
          <button onClick={p.onOpenSettings} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-black/10 py-2 text-xs font-medium hover:bg-black/5 dark:border-white/10 dark:hover:bg-white/5"><Settings2 size={13} /> Params</button>
        </div>
        <div className="flex gap-1.5">
          <button onClick={() => { const blob = new Blob([JSON.stringify(p.sessions, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "nexus-chats.json"; a.click(); }} className="flex flex-1 items-center justify-center gap-1 rounded-lg py-1.5 text-[11px] text-zinc-400 hover:text-zinc-700 dark:hover:text-white"><Download size={11} /> Export</button>
          <label className="flex flex-1 cursor-pointer items-center justify-center gap-1 rounded-lg py-1.5 text-[11px] text-zinc-400 hover:text-zinc-700 dark:hover:text-white"><Upload size={11} /> Import<input type="file" accept="application/json" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; const r = new FileReader(); r.onload = () => { try { const arr = JSON.parse(r.result as string); if (Array.isArray(arr)) { const cur = store.sessions; store.sessions = [...arr, ...cur].slice(0, 200); location.reload(); } } catch {} }; r.readAsText(f); }} /></label>
          <span className="flex-1 py-1.5 text-center font-mono text-[10px] text-zinc-400">local-only</span>
        </div>
        <button onClick={p.onAuth} className="flex w-full items-center gap-2 rounded-xl bg-black px-3 py-2.5 text-xs font-semibold text-white dark:bg-white dark:text-black">
          <span className={cn("h-2 w-2 rounded-full", p.authed ? "bg-emerald-400" : "bg-amber-400")} />
          <span className="truncate">{p.authed ? (p.user?.username || p.user?.email || "Puter connected") : "Connect Puter (for AI credits)"}</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden h-full w-[272px] shrink-0 border-r border-black/10 bg-white/60 dark:border-white/10 dark:bg-[#0e0e11]/80 lg:block">{body}</aside>
      <AnimatePresence>
        {p.open && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={p.onClose} className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm lg:hidden" />
            <motion.aside initial={{ x: -300 }} animate={{ x: 0 }} exit={{ x: -300 }} transition={{ type: "spring", damping: 30, stiffness: 300 }} className="fixed inset-y-0 left-0 z-50 w-[280px] border-r border-black/10 bg-white dark:border-white/10 dark:bg-[#0e0e11] lg:hidden">{body}</motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

// ─── SETTINGS DRAWER ───
export function SettingsDrawer({ open, onClose, settings, onChange, liveCount }: { open: boolean; onClose: () => void; settings: AppSettings; onChange: (s: AppSettings) => void; liveCount: number }) {
  const set = (k: Partial<AppSettings>) => onChange({ ...settings, ...k });
  const checks = checkParams(settings.model, { reasoning_effort: settings.reasoning_effort, temperature: settings.temperature });
  const m = getModel(settings.model);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60]">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <motion.aside initial={{ x: 420 }} animate={{ x: 0 }} exit={{ x: 420 }} transition={{ type: "spring", damping: 32, stiffness: 300 }}
        className="absolute inset-y-0 right-0 flex w-full max-w-[400px] flex-col border-l border-black/10 bg-white dark:border-white/10 dark:bg-[#121215]">
        <div className="flex items-center gap-2 border-b border-black/10 p-4 dark:border-white/10">
          <Settings2 size={16} /><h2 className="text-sm font-bold">Parameters & Tools</h2>
          <span className="ml-auto" /><Chip tone="blue">{liveCount > 0 ? `${liveCount} live models` : m.vendor}</Chip>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg hover:bg-black/5 dark:hover:bg-white/10"><X size={16} /></button>
        </div>
        <div className="flex-1 space-y-5 overflow-y-auto p-4 pb-10">
          {/* MODEL */}
          <Field label="Model" hint={`${m.family} · ${m.tagline} · ctx ${(m.context / 1000).toFixed(0)}k · out ${(m.maxOut / 1000).toFixed(0)}k`}>
            <select value={settings.model} onChange={(e) => set({ model: e.target.value })} className="w-full rounded-xl border border-black/10 bg-transparent p-2.5 text-[13px] dark:border-white/10">
              {MODEL_CATALOG.map((x) => <option key={x.id} value={x.id} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{x.name} — {x.tagline}</option>)}
            </select>
            <div className="mt-2 flex flex-wrap gap-1">
              {m.caps.vision && <Chip tone="green">vision</Chip>}{m.caps.reasoning && <Chip tone="violet">reasoning</Chip>}{m.caps.tools && <Chip tone="blue">tools</Chip>}{m.caps.webSearch && <Chip tone="amber">web_search</Chip>}{m.caps.imageGen && <Chip tone="violet">image-gen</Chip>}{m.caps.thinkingExtended && <Chip>thinking</Chip>}{!checks.temperature.ok && <Chip tone="amber">no-temp</Chip>}
            </div>
          </Field>

          <Field label="System prompt">
            <textarea value={settings.systemPrompt} onChange={(e) => set({ systemPrompt: e.target.value })} rows={3} className="w-full resize-none rounded-xl border border-black/10 bg-black/[.03] p-2.5 text-[12.5px] dark:border-white/10 dark:bg-white/[.05]" />
            <div className="flex flex-wrap gap-1 pt-1">{SYSTEM_PRESETS.map((pr) => <button key={pr.name} onClick={() => set({ systemPrompt: pr.prompt })} className="rounded-full border border-black/10 px-2 py-1 text-[10.5px] hover:bg-black hover:text-white dark:border-white/15 dark:hover:bg-white dark:hover:text-black">{pr.name}</button>)}</div>
            {settings.enableCache && m.vendor === "anthropic" && <p className="text-[11px] text-emerald-600 dark:text-emerald-400">✓ prompt-caching enabled (cache_control: ephemeral on system)</p>}
          </Field>

          {/* SAMPLING */}
          <div className="rounded-2xl border border-black/10 p-3 dark:border-white/10">
            <p className="mb-3 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Sampling</p>
            <div className="space-y-4">
              <Field label={`Temperature · ${settings.temperature}`} warn={!checks.temperature.ok ? checks.temperature.note : undefined} hint={checks.temperature.ok ? checks.temperature.note : undefined} right={<span className={cn("font-mono text-[11px]", checks.temperature.ok ? "text-emerald-500" : "text-amber-500")}>{checks.temperature.ok ? "● active" : "○ omitted"}</span>}>
                <Slider value={settings.temperature} min={0} max={2} step={0.05} onChange={(v) => set({ temperature: v })} disabled={!checks.temperature.ok} />
              </Field>
              <Field label={`Max tokens · ${settings.max_tokens}`} hint={`Model cap ${(m.maxOut / 1000).toFixed(0)}k`}>
                <Slider value={settings.max_tokens} min={256} max={Math.min(128000, m.maxOut)} step={256} onChange={(v) => set({ max_tokens: Math.round(v) })} />
              </Field>
              <Field label="Stop sequences" hint="Comma-separated, e.g. ###, END"><input value={settings.stopSequences} onChange={(e) => set({ stopSequences: e.target.value })} placeholder="###, END" className="w-full rounded-xl border border-black/10 bg-transparent p-2 text-[13px] dark:border-white/10" /></Field>
            </div>
          </div>

          {/* REASONING */}
          <div className="rounded-2xl border border-black/10 p-3 dark:border-white/10">
            <p className="mb-3 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Reasoning & verbosity — smart-gated</p>
            <div className="space-y-4">
              <Field label="Reasoning effort" warn={!checks.reasoning_effort.ok ? checks.reasoning_effort.note : undefined} right={<span className={cn("font-mono text-[11px]", checks.reasoning_effort.ok ? "text-emerald-500" : "text-amber-500")}>{checks.reasoning_effort.ok ? "● sent" : "○ ignored"}</span>}>
                <Seg value={settings.reasoning_effort} onChange={(v: any) => set({ reasoning_effort: v })} options={["none", "minimal", "low", "medium", "high", "xhigh"].map((v) => ({ v: v as any, label: v }))} />
              </Field>
              <Field label="Verbosity" warn={!checks.verbosity.ok ? checks.verbosity.note : undefined} right={<span className={cn("font-mono text-[11px]", checks.verbosity.ok ? "text-emerald-500" : "text-amber-500")}>{checks.verbosity.ok ? "● sent" : "○ ignored"}</span>}>
                <Seg value={settings.verbosity} onChange={(v: any) => set({ verbosity: v })} options={["low", "medium", "high"].map((v) => ({ v: v as any, label: v }))} />
              </Field>
              <Field label="Extended thinking (Claude)" warn={!checks.thinking.ok ? checks.thinking.note : undefined} right={<span className={cn("font-mono text-[11px]", checks.thinking.ok ? "text-emerald-500" : "text-amber-500")}>{checks.thinking.ok ? "● sent" : "○ ignored"}</span>}>
                <Seg value={settings.thinkingType} onChange={(v: any) => set({ thinkingType: v })} options={[{ v: "adaptive", label: "adaptive" }, { v: "enabled", label: "enabled" }, { v: "disabled", label: "disabled" }, { v: "between_tools", label: "between_tools" }] as any} />
                {settings.thinkingType === "enabled" && <div className="pt-2"><Slider value={settings.thinkingBudget} min={1024} max={32000} step={512} onChange={(v) => set({ thinkingBudget: Math.round(v) })} /><p className="font-mono text-[11px] text-zinc-400">budget {settings.thinkingBudget} tokens</p></div>}
              </Field>
            </div>
          </div>

          {/* IMAGE GEN via chat */}
          <div className="rounded-2xl border border-black/10 p-3 dark:border-white/10">
            <p className="mb-3 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Image output (Gemini image models)</p>
            <Field label="Applies when" hint={checks.image_config.note}>
              <div className="grid grid-cols-2 gap-2">
                <select value={settings.imageAspect} onChange={(e) => set({ imageAspect: e.target.value })} className="rounded-xl border border-black/10 bg-transparent p-2 text-[13px] dark:border-white/10">{["1:1", "16:9", "9:16", "4:3", "3:4"].map((r) => <option key={r} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{r}</option>)}</select>
                <select value={settings.imageSize} onChange={(e) => set({ imageSize: e.target.value })} className="rounded-xl border border-black/10 bg-transparent p-2 text-[13px] dark:border-white/10">{["512", "1K", "2K", "4K"].map((r) => <option key={r} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{r}</option>)}</select>
              </div>
            </Field>
          </div>

          {/* TOOLS */}
          <div className="rounded-2xl border border-black/10 p-3 dark:border-white/10">
            <p className="mb-3 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Tools for AI</p>
            <div className="space-y-2.5">
              {[
                { k: "enableWebSearch" as const, t: "Web search (native)", d: m.caps.webSearch ? "tools:[{type:'web_search'}]" : "OpenAI-only natively — auto-mapped to fetch tool", warn: !checks.web_search.ok },
                { k: "enableFunctions" as const, t: "Local functions", d: "calculator · datetime · workspace reader", warn: false },
                { k: "enableWorkspace" as const, t: "Workspace files as context", d: "Attached + toggled files injected", warn: false },
                { k: "enableCache" as const, t: "Prompt caching (Claude)", d: "cache_control ephemeral", warn: false },
              ].map((r) => (
                <div key={r.k} className="flex items-center gap-2.5">
                  <Toggle on={(settings as any)[r.k]} onChange={(v) => set({ [r.k]: v } as any)} />
                  <div className="leading-tight"><p className="text-[13px] font-medium">{r.t} {r.warn && <span className="text-[10px] text-amber-500">· emulated</span>}</p><p className="font-mono text-[10.5px] text-zinc-400">{r.d}</p></div>
                </div>
              ))}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <Field label="tool_choice"><Seg size="sm" value={settings.toolChoice} onChange={(v: any) => set({ toolChoice: v })} options={[{ v: "auto", label: "auto" }, { v: "none", label: "none" }, { v: "required", label: "required" }]} /></Field>
                <div className="flex items-end gap-2 pb-1"><Toggle on={settings.parallelTools} onChange={(v) => set({ parallelTools: v })} /><span className="text-xs">parallel calls</span></div>
              </div>
              <Field label="Structured output (JSON schema)" hint="outputFormat: {type:'json_schema',…}">
                <div className="flex items-center gap-2"><Toggle on={settings.jsonMode} onChange={(v) => set({ jsonMode: v })} /><span className="text-xs text-zinc-400">constrain to schema</span></div>
                {settings.jsonMode && <textarea value={settings.jsonSchema} onChange={(e) => set({ jsonSchema: e.target.value })} rows={4} className="mt-2 w-full rounded-xl border border-black/10 bg-black p-2.5 font-mono text-[11px] text-emerald-300 dark:border-white/10" />}
              </Field>
            </div>
          </div>

          {/* BEHAVIOUR */}
          <div className="rounded-2xl border border-black/10 p-3 dark:border-white/10">
            <p className="mb-3 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Behaviour & transport</p>
            <div className="space-y-2.5">
              {[
                { k: "stream" as const, t: "Stream responses", d: "token-by-token + reasoning chunks" },
                { k: "compaction" as const, t: "Context compaction", d: `trigger @ ${(settings.compactionThreshold / 1000).toFixed(0)}k tokens` },
                { k: "testMode" as const, t: "Test mode (no credits)", d: "sample outputs, validates params" },
              ].map((r) => (
                <div key={r.k} className="flex items-center gap-2.5"><Toggle on={(settings as any)[r.k]} onChange={(v) => set({ [r.k]: v } as any)} /><div className="leading-tight"><p className="text-[13px] font-medium">{r.t}</p><p className="font-mono text-[10.5px] text-zinc-400">{r.d}</p></div></div>
              ))}
              {settings.compaction && <Slider value={settings.compactionThreshold} min={8000} max={200000} step={4000} onChange={(v) => set({ compactionThreshold: Math.round(v) })} />}
              <Field label="normalize"><Seg value={settings.normalize === null ? "auto" : settings.normalize ? "on" : "off"} onChange={(v: any) => set({ normalize: v === "auto" ? null : v === "on" })} options={[{ v: "auto", label: "auto (date rule)" }, { v: "on", label: "force on" }, { v: "off", label: "force off" }]} /></Field>
            </div>
          </div>

          {/* MEDIA DEFAULTS */}
          <div className="rounded-2xl border border-black/10 p-3 dark:border-white/10">
            <p className="mb-3 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Studio defaults</p>
            <div className="space-y-3">
              <Field label="Image model"><select value={settings.imgModel} onChange={(e) => set({ imgModel: e.target.value })} className="w-full rounded-xl border border-black/10 bg-transparent p-2 text-[13px] dark:border-white/10">{IMAGE_MODELS.map((x) => <option key={x.id} value={x.id} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{x.name}</option>)}</select></Field>
              <Field label="Video model"><select value={settings.vidModel} onChange={(e) => set({ vidModel: e.target.value })} className="w-full rounded-xl border border-black/10 bg-transparent p-2 text-[13px] dark:border-white/10">{VIDEO_MODELS.map((x) => <option key={x.id} value={x.id} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{x.name}</option>)}</select></Field>
              <Field label="TTS provider"><select value={settings.ttsProvider} onChange={(e) => set({ ttsProvider: e.target.value })} className="w-full rounded-xl border border-black/10 bg-transparent p-2 text-[13px] dark:border-white/10">{TTS_PRESETS.map((x) => <option key={x.provider} value={x.provider} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{x.name}</option>)}</select></Field>
            </div>
          </div>

          {/* APPEARANCE */}
          <div className="rounded-2xl border border-black/10 p-3 dark:border-white/10">
            <p className="mb-3 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Appearance & UX</p>
            <div className="flex items-center gap-2">
              <button onClick={() => set({ theme: "dark" })} className={cn("flex flex-1 items-center justify-center gap-1.5 rounded-xl border py-2 text-xs", settings.theme === "dark" ? "border-black bg-black text-white dark:border-white dark:bg-white dark:text-black" : "border-black/10 dark:border-white/10")}><Moon size={13} /> Dark</button>
              <button onClick={() => set({ theme: "light" })} className={cn("flex flex-1 items-center justify-center gap-1.5 rounded-xl border py-2 text-xs", settings.theme === "light" ? "border-black bg-black text-white dark:border-white dark:bg-white dark:text-black" : "border-black/10 dark:border-white/10")}><Sun size={13} /> Light</button>
            </div>
            <div className="mt-3 space-y-2.5">
              {[
                { k: "showThinking" as const, t: "Show thinking blocks" },
                { k: "showTools" as const, t: "Show tool calls" },
                { k: "showTokens" as const, t: "Show token counts" },
                { k: "enterToSend" as const, t: "Enter to send (⇧↵ newline)" },
              ].map((r) => (
                <div key={r.k} className="flex items-center gap-2.5"><Toggle on={(settings as any)[r.k]} onChange={(v) => set({ [r.k]: v } as any)} /><span className="text-[13px]">{r.t}</span></div>
              ))}
              <Field label={`Font size · ${settings.fontSize}px`}><Slider value={settings.fontSize} min={12} max={18} step={0.5} onChange={(v) => set({ fontSize: v })} /></Field>
            </div>
          </div>
        </div>
      </motion.aside>
    </div>
  );
}

// ─── WORKSPACE DRAWER ───
export function WorkspaceDrawer({ open, onClose, files, onChange, onToast }: { open: boolean; onClose: () => void; files: WorkspaceFile[]; onChange: (f: WorkspaceFile[]) => void; onToast: (m: string) => void }) {
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const add = () => {
    if (!name.trim() && !content.trim()) return;
    onChange([{ id: uid(), name: name.trim() || `note-${files.length + 1}.md`, kind: "note", content, size: content.length, updatedAt: Date.now(), attach: true }, ...files]);
    setName(""); setContent(""); onToast("File added to workspace");
  };
  const importFile = async (f: File) => {
    if (f.type.startsWith("image/")) {
      const d = await fileToDataUrl(f);
      onChange([{ id: uid(), name: f.name, kind: "image", content: d, size: f.size, updatedAt: Date.now(), attach: true }, ...files]);
    } else {
      const t = await f.text().catch(() => "");
      onChange([{ id: uid(), name: f.name, kind: "doc", content: t.slice(0, 60000), size: f.size, updatedAt: Date.now(), attach: true }, ...files]);
    }
    onToast("Imported " + f.name);
  };
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60]">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <motion.aside initial={{ x: 420 }} animate={{ x: 0 }} className="absolute inset-y-0 right-0 flex w-full max-w-[400px] flex-col border-l border-black/10 bg-white dark:border-white/10 dark:bg-[#121215]">
        <div className="flex items-center gap-2 border-b border-black/10 p-4 dark:border-white/10">
          <FolderOpen size={16} /><h2 className="text-sm font-bold">Workspace files</h2><Chip tone="green">{files.filter((f) => f.attach).length} attached</Chip>
          <span className="ml-auto" /><button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg hover:bg-black/5 dark:hover:bg-white/10"><X size={16} /></button>
        </div>
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          <div className="rounded-2xl border border-black/10 p-3 dark:border-white/10">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-zinc-400">New note (local)</p>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="name.md" className="mb-2 w-full rounded-xl border border-black/10 bg-transparent p-2 text-[13px] dark:border-white/10" />
            <textarea value={content} onChange={(e) => setContent(e.target.value)} rows={3} placeholder="Paste docs, context, style guide… AI reads attached files." className="w-full resize-none rounded-xl border border-black/10 bg-black/[.03] p-2.5 text-[12.5px] dark:border-white/10 dark:bg-white/[.05]" />
            <div className="mt-2 flex gap-2">
              <button onClick={add} className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-black py-2 text-xs font-semibold text-white dark:bg-white dark:text-black"><Plus size={13} /> Add</button>
              <label className="flex flex-1 cursor-pointer items-center justify-center gap-1 rounded-xl border border-black/10 py-2 text-xs font-medium dark:border-white/10"><Upload size={13} /> Import<input type="file" multiple className="hidden" onChange={(e) => { Array.from(e.target.files || []).forEach(importFile); e.target.value = ""; }} /></label>
            </div>
          </div>
          {files.length === 0 && <p className="py-8 text-center text-xs text-zinc-400">No files. Add notes or import docs/images —<br />attached files are injected as AI context.</p>}
          {files.map((f) => (
            <div key={f.id} className="rounded-2xl border border-black/10 p-3 dark:border-white/10">
              <div className="flex items-center gap-2">
                {f.kind === "image" ? <ImageIcon size={14} /> : f.attach ? <Paperclip size={14} /> : <FileText size={14} />}
                <p className="flex-1 truncate text-[13px] font-medium">{f.name}</p>
                <Toggle on={f.attach} onChange={(v) => onChange(files.map((x) => x.id === f.id ? { ...x, attach: v } : x))} />
              </div>
              {f.kind === "image" ? <img src={f.content} className="mt-2 max-h-40 w-full rounded-xl object-cover" alt="" />
                : <p className="mt-2 line-clamp-3 whitespace-pre-wrap font-mono text-[11px] text-zinc-500">{f.content.slice(0, 400)}</p>}
              <div className="mt-2 flex items-center gap-2 text-[11px] text-zinc-400">
                <span>{(f.size / 1024).toFixed(1)} KB · {timeAgo(f.updatedAt)}</span><span className="ml-auto" />
                <button onClick={() => { navigator.clipboard.writeText(f.content); onToast("Copied"); }} className="hover:text-zinc-800 dark:hover:text-white">copy</button>
                <button onClick={() => { const blob = new Blob([f.content], { type: "text/plain" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = f.name; a.click(); }} className="flex items-center gap-0.5 hover:text-zinc-800 dark:hover:text-white"><Download size={11} /> save</button>
                <button onClick={() => onChange(files.filter((x) => x.id !== f.id))} className="text-red-400 hover:text-red-500">delete</button>
              </div>
            </div>
          ))}
          <button onClick={() => { const blob = new Blob([JSON.stringify(files, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "nexus-workspace.json"; a.click(); }} className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-black/10 py-2 text-xs dark:border-white/10"><Download size={12} /> Export workspace JSON</button>
        </div>
      </motion.aside>
    </div>
  );
}

// re-export for App convenience
export { SYSTEM_PRESETS as _SP, store as _store };
export function useLiveCountFix() { return 0; }
