import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Image as ImageIcon, Clapperboard, AudioLines, Upload, Download, Loader2, Play, Sparkles, Mic, FileAudio, ScanText, Wand2, FlaskConical } from "lucide-react";
import { IMAGE_MODELS, VIDEO_MODELS, TTS_PRESETS } from "../lib/puter";
import { store, fileToDataUrl, uid } from "../lib/store";
import { Field, Seg, Toggle, Chip } from "./ui";
import { cn } from "../utils/cn";

async function puter(): Promise<any> {
  const { loadPuter } = await import("../lib/puter");
  return loadPuter();
}
const errMsg = (e: any) => e?.message || e?.error || (typeof e === "string" ? e : "Unknown error");

// ─── IMAGE LAB ───
export function ImageLab({ onToast }: { onToast: (m: string) => void }) {
  const s = store.settings;
  const [prompt, setPrompt] = useState("A cinematic portrait of a fox in neon Tokyo rain, 85mm, shallow depth of field");
  const [model, setModel] = useState(s.imgModel);
  const [quality, setQuality] = useState(s.imgQuality);
  const [ratio, setRatio] = useState(s.imgRatio);
  const [ref, setRef] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<{ src: string; prompt: string; model: string; ts: number }[]>(() => store.gallery.filter((g: any) => g.kind === "image").slice(0, 12));
  const [testMode, setTestMode] = useState(s.testMode);
  const fileRef = useRef<HTMLInputElement>(null);

  const meta = IMAGE_MODELS.find((m) => m.id === model) ?? IMAGE_MODELS[0];

  async function generate() {
    if (!prompt.trim() || busy) return;
    setBusy(true);
    try {
      const p = await puter();
      const [w, h] = ratio.split(":").map(Number);
      const opts: any = { model, test_mode: testMode };
      if (meta.provider === "openai") opts.quality = quality.toLowerCase();
      else if (meta.provider === "gemini") opts.quality = quality;
      else if (meta.provider === "xai") opts.quality = quality.toLowerCase();
      if (meta.provider !== "cloudflare") opts.ratio = { w, h };
      if (ref) opts.input_image = ref;
      const imgEl = await p.ai.txt2img(prompt, opts);
      const src = imgEl?.src || String(imgEl);
      const rec = { src, prompt, model, ts: Date.now(), kind: "image", id: uid() };
      setResults((r) => [rec, ...r].slice(0, 24));
      const g = store.gallery; store.gallery = [rec, ...g].slice(0, 60);
      onToast("Image rendered");
    } catch (e: any) { onToast("Image failed: " + errMsg(e)); }
    setBusy(false);
  }

  return (
    <div className="mx-auto grid w-full max-w-6xl gap-5 px-4 pb-28 pt-6 lg:grid-cols-[340px_1fr]">
      <div className="h-fit space-y-4 rounded-2xl border border-black/10 bg-white p-4 dark:border-white/10 dark:bg-[#121215]">
        <div className="flex items-center gap-2"><ImageIcon size={16} /><h2 className="text-sm font-bold">Image Lab</h2><Chip tone="green">txt2img</Chip><span className="ml-auto" /></div>
        <Field label="Prompt"><textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={4} className="w-full resize-none rounded-xl border border-black/10 bg-black/[.03] p-3 text-[13px] outline-none focus:border-black/30 dark:border-white/10 dark:bg-white/[.05] dark:focus:border-white/30" /></Field>
        <Field label="Model" hint={meta.desc}>
          <select value={model} onChange={(e) => { setModel(e.target.value); const m = IMAGE_MODELS.find((x) => x.id === e.target.value); if (m) setQuality(m.qualities[0]); }} className="w-full rounded-xl border border-black/10 bg-transparent p-2.5 text-[13px] outline-none dark:border-white/10">
            {IMAGE_MODELS.map((m) => <option key={m.id} value={m.id} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{m.name} · {m.provider}</option>)}
          </select>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Quality"><select value={quality} onChange={(e) => setQuality(e.target.value)} className="w-full rounded-xl border border-black/10 bg-transparent p-2.5 text-[13px] dark:border-white/10">{meta.qualities.map((q) => <option key={q} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{q}</option>)}</select></Field>
          <Field label="Aspect"><Seg size="sm" value={ratio} onChange={setRatio} options={["1:1", "16:9", "9:16", "4:3", "3:4"].map((r) => ({ v: r, label: r }))} /></Field>
        </div>
        <Field label="Edit reference" hint="image-to-image: upload a base to repaint">
          <div className="flex items-center gap-2">
            <button onClick={() => fileRef.current?.click()} className="flex items-center gap-1.5 rounded-xl border border-dashed border-black/20 px-3 py-2 text-xs hover:bg-black/5 dark:border-white/20 dark:hover:bg-white/5"><Upload size={13} />{ref ? "Replace" : "Upload"}</button>
            {ref && <><img src={ref} className="h-10 w-10 rounded-lg object-cover" alt="" /><button onClick={() => setRef(null)} className="text-xs text-red-500">remove</button></>}
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setRef(await fileToDataUrl(f)); }} />
          </div>
        </Field>
        <div className="flex items-center justify-between rounded-xl bg-black/[.03] px-3 py-2.5 dark:bg-white/[.05]">
          <span className="flex items-center gap-1.5 text-xs"><FlaskConical size={13} /> Test mode <span className="text-zinc-400">(free sample)</span></span>
          <Toggle on={testMode} onChange={setTestMode} />
        </div>
        <button onClick={generate} disabled={busy || !prompt.trim()} className="flex w-full items-center justify-center gap-2 rounded-xl bg-black py-3 text-sm font-semibold text-white transition hover:opacity-85 disabled:opacity-40 dark:bg-white dark:text-black">
          {busy ? <Loader2 size={16} className="animate-spin" /> : <Wand2 size={16} />}{busy ? "Rendering…" : "Generate image"}
        </button>
      </div>
      <div>
        {results.length === 0 ? (
          <div className="grid h-72 place-items-center rounded-2xl border border-dashed border-black/15 text-sm text-zinc-400 dark:border-white/15">No renders yet — describe something beautiful →</div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {results.map((r, i) => (
              <motion.figure key={r.ts + i} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="group overflow-hidden rounded-2xl border border-black/10 bg-white dark:border-white/10 dark:bg-[#121215]">
                <div className="relative"><img src={r.src} alt={r.prompt} className="aspect-square w-full object-cover" loading="lazy" />
                  <div className="absolute inset-x-0 bottom-0 flex translate-y-2 gap-2 bg-gradient-to-t from-black/70 to-transparent p-3 opacity-0 transition group-hover:translate-y-0 group-hover:opacity-100">
                    <a href={r.src} download={`nexus-${r.ts}.png`} className="flex items-center gap-1 rounded-lg bg-white/90 px-2.5 py-1.5 text-[11px] font-semibold text-black"><Download size={12} /> Save</a>
                    <a href={r.src} target="_blank" rel="noreferrer" className="flex items-center gap-1 rounded-lg bg-white/20 px-2.5 py-1.5 text-[11px] font-semibold text-white backdrop-blur">Open</a>
                  </div></div>
                <figcaption className="p-3 text-xs leading-relaxed"><p className="line-clamp-2 text-zinc-600 dark:text-zinc-300">{r.prompt}</p><p className="mt-1 font-mono text-[10px] text-zinc-400">{r.model}</p></figcaption>
              </motion.figure>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── VIDEO LAB ───
export function VideoLab({ onToast }: { onToast: (m: string) => void }) {
  const s = store.settings;
  const [prompt, setPrompt] = useState("A fox sprinting through a snow-covered forest at dusk, cinematic drone push-in");
  const [model, setModel] = useState(s.vidModel);
  const [seconds, setSeconds] = useState(s.vidSeconds);
  const [size, setSize] = useState(s.vidSize);
  const [audio, setAudio] = useState(s.vidAudio);
  const [neg, setNeg] = useState(s.vidNeg);
  const [refImg, setRefImg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [clips, setClips] = useState<{ src: string; prompt: string; model: string; ts: number }[]>(() => store.gallery.filter((g: any) => g.kind === "video").slice(0, 8));
  const [testMode, setTestMode] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const meta = VIDEO_MODELS.find((m) => m.id === model) ?? VIDEO_MODELS[0];

  async function generate() {
    if (!prompt.trim() || busy) return;
    setBusy(true); setElapsed(0);
    const tick = setInterval(() => setElapsed((e) => e + 1), 1000);
    try {
      const p = await puter();
      const opts: any = { model, seconds, size, generate_audio: audio, negative_prompt: neg || undefined, test_mode: testMode };
      if (refImg) opts.input_reference = refImg;
      const vid: any = await p.ai.txt2vid(prompt, opts);
      const src = vid?.src || vid?.currentSrc || String(vid);
      const rec = { src, prompt, model, ts: Date.now(), kind: "video", id: uid() };
      setClips((c) => [rec, ...c].slice(0, 12));
      const g = store.gallery; store.gallery = [rec, ...g].slice(0, 60);
      onToast("Video ready");
    } catch (e: any) { onToast("Video failed: " + errMsg(e)); }
    clearInterval(tick); setBusy(false);
  }

  return (
    <div className="mx-auto grid w-full max-w-6xl gap-5 px-4 pb-28 pt-6 lg:grid-cols-[340px_1fr]">
      <div className="h-fit space-y-4 rounded-2xl border border-black/10 bg-white p-4 dark:border-white/10 dark:bg-[#121215]">
        <div className="flex items-center gap-2"><Clapperboard size={16} /><h2 className="text-sm font-bold">Video Lab</h2><Chip tone="violet">txt2vid</Chip></div>
        <Field label="Prompt" hint="Subject + motion + camera + mood"><textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={4} className="w-full resize-none rounded-xl border border-black/10 bg-black/[.03] p-3 text-[13px] outline-none focus:border-black/30 dark:border-white/10 dark:bg-white/[.05] dark:focus:border-white/30" /></Field>
        <Field label="Model"><select value={model} onChange={(e) => setModel(e.target.value)} className="w-full rounded-xl border border-black/10 bg-transparent p-2.5 text-[13px] dark:border-white/10">{VIDEO_MODELS.map((m) => <option key={m.id} value={m.id} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{m.name}</option>)}</select><p className="text-[11px] text-zinc-400">{meta.desc}</p></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={`Length · ${seconds}s`}><Seg size="sm" value={String(seconds)} onChange={(v) => setSeconds(Number(v))} options={meta.seconds.map((x) => ({ v: String(x), label: `${x}s` }))} /></Field>
          <Field label="Size"><Seg size="sm" value={size} onChange={setSize} options={meta.sizes.map((x) => ({ v: x, label: x }))} /></Field>
        </div>
        <Field label="Negative prompt"><input value={neg} onChange={(e) => setNeg(e.target.value)} className="w-full rounded-xl border border-black/10 bg-transparent p-2.5 text-[13px] dark:border-white/10" placeholder="blurry, text, watermark" /></Field>
        <div className="space-y-2">
          <div className="flex items-center justify-between rounded-xl bg-black/[.03] px-3 py-2.5 text-xs dark:bg-white/[.05]"><span>Soundtrack</span><Toggle on={audio} onChange={setAudio} /></div>
          <div className="flex items-center justify-between rounded-xl bg-black/[.03] px-3 py-2.5 text-xs dark:bg-white/[.05]"><span className="flex items-center gap-1"><FlaskConical size={12} /> Test mode</span><Toggle on={testMode} onChange={setTestMode} /></div>
        </div>
        <Field label="First frame (image-to-video)"><div className="flex items-center gap-2"><button onClick={() => fileRef.current?.click()} className="flex items-center gap-1.5 rounded-xl border border-dashed border-black/20 px-3 py-2 text-xs dark:border-white/20"><Upload size={13} />{refImg ? "Replace" : "Upload frame"}</button>{refImg && <img src={refImg} className="h-10 w-16 rounded-lg object-cover" alt="" />}<input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setRefImg(await fileToDataUrl(f)); }} /></div></Field>
        <button onClick={generate} disabled={busy || !prompt.trim()} className="flex w-full items-center justify-center gap-2 rounded-xl bg-black py-3 text-sm font-semibold text-white disabled:opacity-40 dark:bg-white dark:text-black">{busy ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />}{busy ? `Rendering… ${elapsed}s` : "Generate video"}</button>
        {busy && <p className="text-center text-[11px] text-zinc-400">Video takes 30s–3min. Keep this tab open.</p>}
      </div>
      <div className="space-y-4">
        {clips.length === 0 && !busy && <div className="grid h-72 place-items-center rounded-2xl border border-dashed border-black/15 text-sm text-zinc-400 dark:border-white/15">No clips yet — direct your first shot →</div>}
        {busy && <div className="overflow-hidden rounded-2xl border border-black/10 dark:border-white/10"><div className="thinking-track h-1 bg-white/10" /><div className="grid h-56 place-items-center text-sm text-zinc-400"><span className="flex items-center gap-2"><Loader2 className="animate-spin" size={16} /> Rendering on {meta.name}… {elapsed}s</span></div></div>}
        {clips.map((c) => (
          <figure key={c.ts} className="overflow-hidden rounded-2xl border border-black/10 bg-white dark:border-white/10 dark:bg-[#121215]">
            <video src={c.src} controls preload="metadata" className="max-h-[420px] w-full bg-black" />
            <figcaption className="flex items-center gap-2 p-3 text-xs"><span className="line-clamp-1 flex-1 text-zinc-600 dark:text-zinc-300">{c.prompt}</span><Chip>{c.model}</Chip><a href={c.src} download={`nexus-${c.ts}.mp4`} className="flex items-center gap-1 font-semibold hover:underline"><Download size={12} /> MP4</a></figcaption>
          </figure>
        ))}
      </div>
    </div>
  );
}

// ─── VOICE LAB (TTS + STT + OCR) ───
export function VoiceLab({ onToast }: { onToast: (m: string) => void }) {
  const s = store.settings;
  const [tab, setTab] = useState<"tts" | "stt" | "ocr">("tts");
  const [text, setText] = useState("Hello world! Nexus is a local-first AI studio — no accounts, everything saved on this device.");
  const [provider, setProvider] = useState(s.ttsProvider);
  const [voice, setVoice] = useState(s.ttsVoice);
  const [vmodel, setVmodel] = useState(s.ttsModel);
  const [instructions, setInstructions] = useState(s.ttsInstructions);
  const [busy, setBusy] = useState(false);
  const [audioSrc, setAudioSrc] = useState<string | null>(null);
  const [transcript, setTranscript] = useState("");
  const [ocrText, setOcrText] = useState("");
  const [ocrImg, setOcrImg] = useState<string | null>(null);
  const fRef = useRef<HTMLInputElement>(null);
  const preset = TTS_PRESETS.find((t) => t.provider === provider) ?? TTS_PRESETS[0];

  async function speak() {
    if (!text.trim() || busy) return;
    setBusy(true);
    try {
      const p = await puter();
      const audio: any = await p.ai.txt2speech(text.slice(0, 3000), { provider, voice, model: vmodel, instructions: provider === "openai" || provider === "gemini" ? instructions : undefined, language: "en-US", engine: provider === "aws-polly" ? vmodel : undefined });
      const src = audio?.src || audio?.currentSrc || "";
      setAudioSrc(src);
      const el = new Audio(src); el.play().catch(() => {});
      onToast("Speech synthesized");
    } catch (e: any) { onToast("TTS failed: " + errMsg(e)); }
    setBusy(false);
  }

  async function transcribeFile(f: File) {
    setBusy(true); setTranscript("Transcribing…");
    try {
      const p = await puter();
      const r: any = await p.ai.speech2txt(f, { model: "whisper-1" });
      setTranscript(typeof r === "string" ? r : r?.text || JSON.stringify(r, null, 2));
      onToast("Transcribed");
    } catch (e: any) { setTranscript("Failed: " + errMsg(e)); }
    setBusy(false);
  }

  async function runOcr() {
    if (!ocrImg) return;
    setBusy(true); setOcrText("Reading image…");
    try {
      const p = await puter();
      if (p.ai.img2txt) {
        const r: any = await p.ai.img2txt(ocrImg);
        setOcrText(typeof r === "string" ? r : r?.text || JSON.stringify(r, null, 2));
      } else {
        const r: any = await p.ai.chat("Transcribe ALL text visible in this image. Return only the text.", ocrImg, { model: "gpt-5.4-nano" });
        const c = r?.message?.content ?? r;
        setOcrText(typeof c === "string" ? c : JSON.stringify(c, null, 2));
      }
      onToast("OCR done");
    } catch (e: any) { setOcrText("Failed: " + errMsg(e)); }
    setBusy(false);
  }

  return (
    <div className="mx-auto w-full max-w-4xl space-y-5 px-4 pb-28 pt-6">
      <div className="flex items-center gap-2">
        <AudioLines size={16} /><h2 className="text-sm font-bold">Voice & OCR Lab</h2>
        <div className="ml-auto"><Seg value={tab} onChange={setTab} options={[{ v: "tts", label: "Text → Speech" }, { v: "stt", label: "Speech → Text" }, { v: "ocr", label: "OCR" }]} /></div>
      </div>

      {tab === "tts" && (
        <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
          <div className="space-y-4 rounded-2xl border border-black/10 bg-white p-4 dark:border-white/10 dark:bg-[#121215]">
            <Field label={`${text.length} / 3000 chars`}><textarea value={text} onChange={(e) => setText(e.target.value)} rows={7} className="w-full resize-none rounded-xl border border-black/10 bg-black/[.03] p-3 text-[13px] dark:border-white/10 dark:bg-white/[.05]" /></Field>
            <Field label="Style instructions" hint="OpenAI + Gemini only"><input value={instructions} onChange={(e) => setInstructions(e.target.value)} className="w-full rounded-xl border border-black/10 bg-transparent p-2.5 text-[13px] dark:border-white/10" /></Field>
            {audioSrc && <audio src={audioSrc} controls className="w-full" />}
            <button onClick={speak} disabled={busy || !text.trim()} className="flex w-full items-center justify-center gap-2 rounded-xl bg-black py-3 text-sm font-semibold text-white disabled:opacity-40 dark:bg-white dark:text-black">{busy ? <Loader2 className="animate-spin" size={16} /> : <Sparkles size={16} />}{busy ? "Synthesizing…" : "Synthesize & play"}</button>
          </div>
          <div className="h-fit space-y-4 rounded-2xl border border-black/10 bg-white p-4 dark:border-white/10 dark:bg-[#121215]">
            <Field label="Provider"><select value={provider} onChange={(e) => { setProvider(e.target.value); const pr = TTS_PRESETS.find((t) => t.provider === e.target.value)!; setVmodel(pr.models[0]); setVoice(pr.voices[0].split(" ")[0]); }} className="w-full rounded-xl border border-black/10 bg-transparent p-2.5 text-[13px] dark:border-white/10">{TTS_PRESETS.map((t) => <option key={t.provider} value={t.provider} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{t.name}</option>)}</select></Field>
            <Field label="Model / Engine"><select value={vmodel} onChange={(e) => setVmodel(e.target.value)} className="w-full rounded-xl border border-black/10 bg-transparent p-2.5 text-[13px] dark:border-white/10">{preset.models.map((m) => <option key={m} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{m}</option>)}</select></Field>
            <Field label="Voice"><select value={voice} onChange={(e) => setVoice(e.target.value)} className="w-full rounded-xl border border-black/10 bg-transparent p-2.5 text-[13px] dark:border-white/10">{preset.voices.map((m) => <option key={m} className="bg-white text-black dark:bg-zinc-900 dark:text-white">{m}</option>)}</select>
              {provider === "elevenlabs" && <input value={voice} onChange={(e) => setVoice(e.target.value)} placeholder="Paste ElevenLabs voice ID" className="mt-2 w-full rounded-xl border border-black/10 bg-transparent p-2.5 font-mono text-xs dark:border-white/10" />}</Field>
            <div className="rounded-xl bg-black/[.03] p-3 text-[11px] leading-relaxed text-zinc-500 dark:bg-white/[.05] dark:text-zinc-400">xAI voices: eve (energetic) · ara (warm) · rex (confident) · sal (smooth) · leo (authoritative). Supports [pause] [laugh] &lt;whisper&gt; tags.</div>
          </div>
        </div>
      )}

      {tab === "stt" && (
        <div className="rounded-2xl border border-black/10 bg-white p-5 dark:border-white/10 dark:bg-[#121215]">
          <div onClick={() => fRef.current?.click()} className="grid cursor-pointer place-items-center gap-2 rounded-2xl border border-dashed border-black/20 px-6 py-12 text-center hover:bg-black/[.02] dark:border-white/20 dark:hover:bg-white/[.03]">
            <Mic size={22} className="text-zinc-400" />
            <p className="text-sm font-medium">Drop an audio file or click to transcribe</p>
            <p className="font-mono text-[11px] text-zinc-400">whisper-1 · gpt-4o-transcribe · mp3/wav/m4a</p>
            <input ref={fRef} type="file" accept="audio/*,video/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) transcribeFile(f); }} />
          </div>
          {transcript && <div className="mt-4 whitespace-pre-wrap rounded-xl bg-black/[.03] p-4 text-[13px] leading-relaxed dark:bg-white/[.05]">{transcript}</div>}
          <div className={cn("mt-3 flex items-center gap-2 text-xs text-zinc-400")}><FileAudio size={13} /> Also: record voice in chat composer mic, then transcribe.</div>
        </div>
      )}

      {tab === "ocr" && (
        <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
          <div className="rounded-2xl border border-black/10 bg-white p-4 dark:border-white/10 dark:bg-[#121215]">
            <label className="grid cursor-pointer place-items-center gap-2 rounded-xl border border-dashed border-black/20 py-10 text-sm hover:bg-black/[.02] dark:border-white/20">
              <ScanText size={20} className="text-zinc-400" />{ocrImg ? "Replace image" : "Upload image with text"}
              <input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setOcrImg(await fileToDataUrl(f)); }} />
            </label>
            {ocrImg && <img src={ocrImg} className="mt-3 max-h-72 w-full rounded-xl object-contain bg-black/5 dark:bg-white/5" alt="" />}
            <button onClick={runOcr} disabled={!ocrImg || busy} className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-black py-2.5 text-sm font-semibold text-white disabled:opacity-40 dark:bg-white dark:text-black">{busy ? <Loader2 size={15} className="animate-spin" /> : <ScanText size={15} />} Extract text</button>
          </div>
          <div className="whitespace-pre-wrap rounded-2xl border border-black/10 bg-white p-4 text-[13px] leading-relaxed dark:border-white/10 dark:bg-[#121215]">{ocrText || <span className="text-zinc-400">OCR output appears here…</span>}</div>
        </div>
      )}
    </div>
  );
}
