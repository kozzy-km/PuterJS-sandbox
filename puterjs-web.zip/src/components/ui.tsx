import React from "react";
import { cn } from "../utils/cn";

export const Toggle = ({ on, onChange, accent = "#fff" }: { on: boolean; onChange: (v: boolean) => void; accent?: string }) => (
  <button onClick={() => onChange(!on)} className={cn("relative h-[22px] w-[38px] shrink-0 rounded-full transition-colors duration-200", on ? "" : "bg-black/15 dark:bg-white/15")} style={on ? { background: accent === "#ffffff" ? "#0a0a0b" : accent } : undefined} aria-pressed={on}>
    <span className={cn("toggle-dot absolute top-[3px] h-[16px] w-[16px] rounded-full shadow", on ? "left-[19px] bg-white" : "left-[3px] bg-white dark:bg-zinc-300")} style={on && accent === "#ffffff" ? { background: "#fff" } : undefined} />
  </button>
);

export const Slider = ({ value, min, max, step, onChange, disabled }: { value: number; min: number; max: number; step: number; onChange: (v: number) => void; disabled?: boolean }) => {
  const fill = ((value - min) / (max - min)) * 100;
  return (
    <input type="range" className="slider w-full text-zinc-900 dark:text-white disabled:opacity-30" style={{ ["--fill" as any]: `${fill}%` }}
      min={min} max={max} step={step} value={value} disabled={disabled}
      onChange={(e) => onChange(parseFloat(e.target.value))} />
  );
};

export const Seg = <T extends string>({ options, value, onChange, size = "md" }: { options: { v: T; label: string; hint?: string }[]; value: T; onChange: (v: T) => void; size?: "sm" | "md" }) => (
  <div className="flex flex-wrap gap-1 rounded-xl bg-black/[.05] p-1 dark:bg-white/[.07]">
    {options.map((o) => (
      <button key={o.v} title={o.hint} onClick={() => onChange(o.v)}
        className={cn("rounded-lg font-medium transition-all", size === "sm" ? "px-2 py-1 text-[11px]" : "px-2.5 py-1.5 text-xs",
          value === o.v ? "bg-white text-black shadow dark:bg-white dark:text-black" : "text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white")}>
        {o.label}
      </button>
    ))}
  </div>
);

export const Field = ({ label, hint, warn, children, right }: { label: string; hint?: string; warn?: string; children: React.ReactNode; right?: React.ReactNode }) => (
  <div className="space-y-1.5">
    <div className="flex items-center justify-between">
      <label className="text-[11px] font-semibold uppercase tracking-[.08em] text-zinc-500 dark:text-zinc-400">{label}</label>
      {right}
    </div>
    {children}
    {warn ? <p className="flex gap-1 text-[11px] leading-snug text-amber-600 dark:text-amber-400">⚠ {warn}</p>
      : hint ? <p className="text-[11px] leading-snug text-zinc-400 dark:text-zinc-500">{hint}</p> : null}
  </div>
);

export const Chip = ({ children, tone = "zinc", onClick }: { children: React.ReactNode; tone?: "zinc" | "green" | "amber" | "red" | "blue" | "violet"; onClick?: () => void }) => {
  const tones: Record<string, string> = {
    zinc: "bg-black/5 text-zinc-600 dark:bg-white/10 dark:text-zinc-300",
    green: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
    amber: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
    red: "bg-red-500/10 text-red-600 dark:text-red-400",
    blue: "bg-sky-500/10 text-sky-600 dark:text-sky-400",
    violet: "bg-violet-500/10 text-violet-600 dark:text-violet-300",
  };
  return <span onClick={onClick} className={cn("inline-flex cursor-default items-center gap-1 rounded-full px-2 py-[3px] text-[10.5px] font-medium", tones[tone])}>{children}</span>;
};

export const IconBtn = ({ children, onClick, title, active, danger }: { children: React.ReactNode; onClick?: (e: any) => void; title?: string; active?: boolean; danger?: boolean }) => (
  <button title={title} onClick={onClick}
    className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg transition-all",
      active ? "bg-black text-white dark:bg-white dark:text-black"
        : danger ? "text-zinc-400 hover:bg-red-500/10 hover:text-red-500"
          : "text-zinc-500 hover:bg-black/5 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-white/10 dark:hover:text-white")}>
    {children}
  </button>
);

export const ModalShell = ({ children, onClose }: { children: React.ReactNode; onClose: () => void }) => (
  <div className="fixed inset-0 z-[70] grid place-items-center p-4">
    <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
    <div className="animate-float-in relative max-h-[86vh] w-full max-w-lg overflow-hidden rounded-2xl border border-black/10 bg-white shadow-2xl dark:border-white/10 dark:bg-[#131316]">
      {children}
    </div>
  </div>
);

export const Meter = ({ value, max, tone = "bg-zinc-900 dark:bg-white" }: { value: number; max: number; tone?: string }) => (
  <div className="h-1.5 w-full overflow-hidden rounded-full bg-black/10 dark:bg-white/10">
    <div className={cn("h-full rounded-full transition-all duration-700", tone)} style={{ width: `${Math.min(100, (value / Math.max(1, max)) * 100)}%` }} />
  </div>
);
